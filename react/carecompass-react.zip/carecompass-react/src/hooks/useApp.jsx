// src/hooks/useApp.jsx
import { createContext, useContext, useState, useCallback, useRef } from 'react';

const AppCtx = createContext(null);

export function AppProvider({ children }) {
  const [role, setRoleState] = useState('patient');
  const [view, setView]      = useState('home');
  const [toasts, setToasts]  = useState([]);
  const [modal, setModal]    = useState(null); // { id, props }
  const [aiKeys, setAiKeys]  = useState({ cohere: '', anthropic: '' });
  const toastId = useRef(0);

  const setRole = useCallback((r) => {
    setRoleState(r);
    setView(r === 'patient' ? 'p-overview' : 'prov-overview');
  }, []);

  const go = useCallback((id) => setView(id), []);

  const toast = useCallback((title, sub = '', icon = '✅') => {
    const id = ++toastId.current;
    setToasts(t => [...t, { id, title, sub, icon }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3400);
  }, []);

  const openModal  = useCallback((id, props = {}) => setModal({ id, props }), []);
  const closeModal = useCallback(() => setModal(null), []);

  return (
    <AppCtx.Provider value={{ role, setRole, view, go, toast, toasts, modal, openModal, closeModal, aiKeys, setAiKeys }}>
      {children}
    </AppCtx.Provider>
  );
}

export const useApp = () => useContext(AppCtx);
