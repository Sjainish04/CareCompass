// src/App.jsx
import { useApp } from './hooks/useApp';
import Sidebar  from './components/layout/Sidebar';
import Topbar   from './components/layout/Topbar';
import { ToastContainer, ModalHost } from './components/shared/Toast';

import PatientOverview   from './components/patient/PatientOverview';
import Navigator         from './components/patient/Navigator';
import FindCare          from './components/patient/FindCare';
import { AITranslation } from './components/ai/AITranslation';
import { AIRecorder }    from './components/ai/AIRecorder';
import { AICDISC }       from './components/ai/AICDISC';

import {
  HomeView, PatientJourney, PatientAppointments,
  PatientReferrals, PatientRecords,
  ProviderOverview, SettingsView,
} from './components/Views';

// Views that use full-height flex layout (no scroll wrapper)
const FLEX_VIEWS = new Set(['find-care', 'p-navigator']);

export default function App() {
  const { view } = useApp();

  const VIEW_MAP = {
    'home':           <HomeView/>,
    'p-overview':     <PatientOverview/>,
    'p-journey':      <PatientJourney/>,
    'p-appointments': <PatientAppointments/>,
    'p-referrals':    <PatientReferrals/>,
    'p-navigator':    <Navigator/>,
    'p-records':      <PatientRecords/>,
    'find-care':      <FindCare/>,
    'prov-overview':  <ProviderOverview/>,
    'ai-translation': <AITranslation/>,
    'ai-recorder':    <AIRecorder/>,
    'ai-cdisc':       <AICDISC/>,
    'settings':       <SettingsView/>,
  };

  const content = VIEW_MAP[view] || <HomeView/>;

  return (
    <>
      <div className="shell">
        <Sidebar/>
        <div className="main">
          <Topbar/>
          {FLEX_VIEWS.has(view)
            ? content
            : <div style={{ flex:1, overflowY:'auto' }}>{content}</div>
          }
        </div>
      </div>
      <ToastContainer/>
      <ModalHost/>
    </>
  );
}
