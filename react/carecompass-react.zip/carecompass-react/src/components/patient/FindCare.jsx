// src/components/patient/FindCare.jsx
import { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '../../hooks/useApp';
import { CLINICS, geoToXY } from '../../data';

const ROADS = [
  [[43.756,-79.85],[43.756,-79.60],[43.749,-79.38],[43.745,-79.20],[43.740,-79.13]],
  [[43.90,-79.388],[43.75,-79.388],[43.65,-79.387],[43.58,-79.384]],
  [[43.77,-79.35],[43.74,-79.35],[43.69,-79.345],[43.66,-79.340],[43.64,-79.360]],
  [[43.76,-79.56],[43.69,-79.56],[43.62,-79.56]],
  [[43.71,-79.85],[43.706,-79.38],[43.700,-79.13]],
  [[43.78,-79.85],[43.771,-79.38],[43.765,-79.13]],
];

function starsH(r) {
  return Array.from({length:5},(_,i)=><span key={i} style={{color:i<Math.floor(r)?'#f59e0b':'rgba(255,255,255,.13)',fontSize:'.65rem'}}>★</span>);
}

export default function FindCare() {
  const { openModal, toast } = useApp();
  const svgRef = useRef(null);
  const [vb, setVb] = useState({ x:0, y:0, w:800, h:600 });
  const drag = useRef({ active:false, lx:0, ly:0 });
  const [vis, setVis]       = useState(CLINICS);
  const [selId, setSelId]   = useState(null);
  const [detOpen, setDet]   = useState(false);
  const [tipPos, setTipPos] = useState(null);
  const [tipClinic, setTipClinic] = useState(null);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState(new Set(['all']));
  const [sort, setSort]     = useState('dist');
  const [mapFilt, setMapFilt] = useState('all');
  const [selSlot, setSelSlot] = useState(null);

  const selClinic = CLINICS.find(c=>c.id===selId);

  const applyFilters = useCallback((s=search, f=filters, sf=sort, mf=mapFilt) => {
    let list = CLINICS.filter(c => {
      const mq = !s || c.name.toLowerCase().includes(s.toLowerCase()) || c.spec.toLowerCase().includes(s.toLowerCase()) || c.langs.some(l=>l.toLowerCase().includes(s.toLowerCase()));
      let mf2 = true;
      if (!f.has('all')) mf2 = [...f].some(fv => fv==='__acc'?c.acc:fv==='__open'?c.open:c.spec===fv);
      let mm = true;
      if (mf==='__open') mm=c.open; if (mf==='__acc') mm=c.acc;
      return mq && mf2 && mm;
    });
    if (sf==='dist') list.sort((a,b)=>a.dist-b.dist);
    else if (sf==='rating') list.sort((a,b)=>b.rating-a.rating);
    else if (sf==='wait') list.sort((a,b)=>a.wait-b.wait);
    else list.sort((a,b)=>a.name.localeCompare(b.name));
    setVis(list);
  }, []);

  function toggleFilter(type) {
    setFilters(prev => {
      const next = new Set(prev);
      if (type==='all') return new Set(['all']);
      next.delete('all');
      next.has(type) ? next.delete(type) : next.add(type);
      if (!next.size) return new Set(['all']);
      return next;
    });
  }

  useEffect(() => { applyFilters(search, filters, sort, mapFilt); }, [search, filters, sort, mapFilt]);

  // SVG drag
  function onMouseDown(e) { drag.current = { active:true, lx:e.clientX, ly:e.clientY }; }
  function onMouseMove(e) {
    if (!drag.current.active) return;
    const r = svgRef.current?.getBoundingClientRect();
    if (!r) return;
    setVb(v => {
      const dx = (e.clientX-drag.current.lx)*(v.w/r.width);
      const dy = (e.clientY-drag.current.ly)*(v.h/r.height);
      drag.current.lx = e.clientX; drag.current.ly = e.clientY;
      return { ...v, x:Math.max(-200,Math.min(v.x+dx,600)), y:Math.max(-150,Math.min(v.y+dy,350)) };
    });
  }
  function onMouseUp() { drag.current.active = false; }
  function onWheel(e) {
    e.preventDefault();
    const r = svgRef.current?.getBoundingClientRect();
    if (!r) return;
    const f = e.deltaY>0?1.15:.87;
    setVb(v => {
      const mx=(e.clientX-r.left)/r.width*v.w+v.x, my=(e.clientY-r.top)/r.height*v.h+v.y;
      const nw=Math.max(260,Math.min(1600,v.w*f)), nh=Math.max(195,Math.min(1200,v.h*f));
      return { x:mx-(e.clientX-r.left)/r.width*nw, y:my-(e.clientY-r.top)/r.height*nh, w:nw, h:nh };
    });
  }
  function zoom(dir) {
    setVb(v => {
      const f=dir>0?.7:1.4;
      const nw=Math.max(260,Math.min(1600,v.w*f)), nh=Math.max(195,Math.min(1200,v.h*f));
      return { x:v.x+v.w/2-nw/2, y:v.y+v.h/2-nh/2, w:nw, h:nh };
    });
  }

  return (
    <div className="viewflex-content">
      {/* Left panel */}
      <div className="fpanel">
        <div style={{ padding:'1rem 1.15rem 0' }}>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.05rem', fontWeight:700, marginBottom:'.2rem' }}>Find Care Near You</div>
          <div style={{ fontSize:'.67rem', color:'var(--muted)' }}>{vis.length} clinics in the GTA</div>
        </div>
        {/* Search */}
        <div style={{ position:'relative', margin:'.72rem 1.15rem 0' }}>
          <span style={{ position:'absolute', left:'.75rem', top:'50%', transform:'translateY(-50%)', fontSize:'.82rem', color:'var(--muted)' }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Clinic, specialty, or language…" style={{ width:'100%', background:'var(--card)', border:'1px solid var(--border)', borderRadius:10, padding:'.58rem .85rem .58rem 2.2rem', color:'var(--white)', fontFamily:"'DM Sans',sans-serif", fontSize:'.77rem', outline:'none' }}/>
        </div>
        {/* Filters */}
        <div style={{ display:'flex', gap:'.3rem', padding:'.58rem 1.15rem', overflowX:'auto', flexShrink:0 }}>
          {[['all','All'],['Family Medicine','Family'],['Cardiology','Cardiology'],['Internal Medicine','Internal'],['Mental Health','Mental'],['Paediatrics','Paeds'],['__acc','Accepting'],['__open','Open Now']].map(([v,l])=>(
            <button key={v} onClick={()=>toggleFilter(v)} style={{ whiteSpace:'nowrap', padding:'.26rem .68rem', borderRadius:100, fontSize:'.65rem', fontWeight:500, cursor:'pointer', border:`1px solid ${filters.has(v)?'var(--bh)':'var(--border)'}`, background: filters.has(v)?'rgba(109,40,217,.18)':'transparent', color: filters.has(v)?'var(--white)':'var(--dim)', fontFamily:"'DM Sans',sans-serif", flexShrink:0 }}>{l}</button>
          ))}
        </div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 1.15rem .45rem', fontSize:'.65rem', color:'var(--muted)' }}>
          <span>{vis.length} clinics</span>
          <select value={sort} onChange={e=>setSort(e.target.value)} style={{ background:'transparent', border:'none', color:'var(--amethyst)', fontFamily:"'DM Sans',sans-serif", fontSize:'.65rem', cursor:'pointer', outline:'none' }}>
            <option value="dist">Nearest</option><option value="rating">Top rated</option>
            <option value="wait">Shortest wait</option><option value="name">A–Z</option>
          </select>
        </div>
        {/* Clinic list */}
        <div style={{ flex:1, overflowY:'auto', padding:'0 .6rem .7rem' }}>
          {vis.map(c => (
            <div key={c.id} className={`ccard${selId===c.id?' sel':''}`} onClick={()=>{ setSelId(c.id); setDet(true); setSelSlot(null); }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:'.35rem', marginBottom:'.48rem' }}>
                <div><div style={{ fontSize:'.82rem', fontWeight:600 }}>{c.icon} {c.name}</div><div style={{ fontSize:'.62rem', color:'var(--amethyst)', marginTop:'.1rem' }}>{c.spec}</div></div>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap:'.22rem', flexShrink:0 }}>
                  <span className={`chip chip-${c.acc?'g':'r'}`}>{c.acc?'✓ Accepting':'Waitlist'}</span>
                  <span style={{ fontSize:'.6rem', color:'var(--muted)', fontFamily:"'DM Mono',monospace" }}>{c.dist}km</span>
                </div>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:'.28rem', marginBottom:'.42rem' }}>
                <div style={{ display:'flex', gap:1 }}>{starsH(c.rating)}</div>
                <span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.7rem' }}>{c.rating}</span>
                <span style={{ fontSize:'.6rem', color:'var(--muted)' }}>({c.rc.toLocaleString()})</span>
              </div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:'.28rem', marginBottom:'.48rem' }}>
                <span className={`chip chip-${c.open?'g':'r'}`}>{c.open?'● Open':'● Closed'}</span>
                <span className="chip chip-y">⏱ {c.wait}d</span>
                {c.langs.slice(0,3).map(l=><span key={l} className="chip chip-t">🌐 {l}</span>)}
                {c.langs.length>3&&<span className="chip chip-t">+{c.langs.length-3}</span>}
              </div>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:'.62rem', color:'var(--muted)', flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', marginRight:'.5rem' }}>📍 {c.addr}</span>
                <button className="btn btn-p" style={{ fontSize:'.67rem', padding:'.34rem .82rem' }} onClick={e=>{ e.stopPropagation(); openModal('clinicBook',{clinic:c}); }}>Book →</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Map area */}
      <div style={{ flex:1, position:'relative', background:'#080515', overflow:'hidden' }}>
        <svg ref={svgRef} viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`} style={{ width:'100%', height:'100%', cursor:'grab', display:'block' }}
          onMouseDown={onMouseDown} onMouseMove={onMouseMove} onMouseUp={onMouseUp} onMouseLeave={onMouseUp}
          onWheel={onWheel}>
          <rect x={0} y={0} width={800} height={600} fill="#080515"/>
          {Array.from({length:9},(_,i)=><line key={`v${i}`} x1={i*100} y1={0} x2={i*100} y2={600} stroke="rgba(139,92,246,0.06)" strokeWidth={1}/>)}
          {Array.from({length:7},(_,i)=><line key={`h${i}`} x1={0} y1={i*100} x2={800} y2={i*100} stroke="rgba(139,92,246,0.06)" strokeWidth={1}/>)}
          {ROADS.map((pts,ri)=>{
            const d=pts.map((p,i)=>{const {x,y}=geoToXY(p[0],p[1]);return(i?'L':'M')+x.toFixed(1)+','+y.toFixed(1);}).join(' ');
            return <path key={ri} d={d} fill="none" stroke="rgba(139,92,246,0.18)" strokeWidth={2.2} strokeLinecap="round"/>;
          })}
          <path d="M 0,555 C 150,538 300,550 450,546 C 600,542 720,548 800,551 L 800,600 L 0,600 Z" fill="rgba(59,130,246,0.12)" stroke="rgba(59,130,246,0.22)" strokeWidth={1}/>
          <text x={400} y={584} textAnchor="middle" fill="rgba(147,197,253,0.32)" fontSize={10} fontFamily="DM Sans,sans-serif" letterSpacing={4}>LAKE ONTARIO</text>
          <text x={380} y={325} textAnchor="middle" fill="rgba(255,255,255,0.04)" fontSize={34} fontFamily="Playfair Display,serif" fontWeight={700}>TORONTO</text>
          {vis.map(c => {
            const {x,y} = geoToXY(c.lat, c.lng);
            const sel = c.id === selId;
            return (
              <g key={c.id} style={{ cursor:'pointer' }}
                onMouseEnter={e=>{ setTipClinic(c); setTipPos({x:e.clientX+14,y:e.clientY-90}); }}
                onMouseLeave={()=>setTipClinic(null)}
                onClick={()=>{ setSelId(c.id); setDet(true); setSelSlot(null); }}>
                {sel && <circle cx={x} cy={y} r={17} fill="none" stroke={c.color} strokeWidth={2} opacity={.38}/>}
                <circle cx={x} cy={y} r={sel?11:8} fill={c.color} stroke="rgba(255,255,255,0.82)" strokeWidth={sel?2.2:1.8} opacity={c.open?1:.5}/>
              </g>
            );
          })}
        </svg>

        {/* Map controls */}
        <div style={{ position:'absolute', top:'.85rem', left:'.85rem', zIndex:10, display:'flex', gap:'.35rem', flexWrap:'wrap' }}>
          {[['all','All'],['__open','Open Now'],['__acc','Accepting']].map(([v,l])=>(
            <button key={v} onClick={()=>setMapFilt(v)} style={{ background:'rgba(19,10,37,.94)', border:`1px solid ${mapFilt===v?'var(--bh)':'var(--border)'}`, padding:'.4rem .72rem', borderRadius:8, fontSize:'.69rem', color: mapFilt===v?'var(--white)':'var(--dim)', cursor:'pointer', fontFamily:"'DM Sans',sans-serif" }}>{l}</button>
          ))}
          <button onClick={()=>zoom(1)} style={{ background:'rgba(19,10,37,.94)', border:'1px solid var(--border)', padding:'.4rem .6rem', borderRadius:8, fontSize:'.69rem', color:'var(--dim)', cursor:'pointer' }}>＋</button>
          <button onClick={()=>zoom(-1)} style={{ background:'rgba(19,10,37,.94)', border:'1px solid var(--border)', padding:'.4rem .6rem', borderRadius:8, fontSize:'.69rem', color:'var(--dim)', cursor:'pointer' }}>－</button>
        </div>

        {/* Stats overlay */}
        <div style={{ position:'absolute', top:'.85rem', right:'.85rem', zIndex:10, background:'rgba(19,10,37,.94)', border:'1px solid var(--border)', borderRadius:10, padding:'.68rem .9rem' }}>
          {[['Showing',vis.length],['Accepting',vis.filter(c=>c.acc).length],['Languages','10+']].map(([l,v])=>(
            <div key={l} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:'1.4rem', marginBottom:'.24rem', fontSize:'.66rem', color:'var(--dim)' }}>
              <span>{l}</span><span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.72rem', color:'var(--white)', fontWeight:500 }}>{v}</span>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div style={{ position:'absolute', bottom:'.85rem', left:'.85rem', zIndex:10, background:'rgba(19,10,37,.94)', border:'1px solid var(--border)', borderRadius:10, padding:'.65rem .85rem' }}>
          <div style={{ fontSize:'.52rem', fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--muted)', marginBottom:'.42rem' }}>Specialty</div>
          {[['#7c3aed','Family'],['#db2777','Cardiology'],['#0891b2','Internal'],['#059669','Mental Health'],['#d97706','Paediatrics'],['#6366f1','Other']].map(([c,l])=>(
            <div key={l} style={{ display:'flex', alignItems:'center', gap:'.42rem', marginBottom:'.24rem', fontSize:'.63rem', color:'var(--dim)' }}>
              <div style={{ width:8, height:8, borderRadius:'50%', background:c, flexShrink:0 }}/>{l}
            </div>
          ))}
        </div>

        {/* Tooltip */}
        {tipClinic && tipPos && (
          <div className="maptip" style={{ left:tipPos.x, top:tipPos.y }}>
            <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'.85rem', fontWeight:700, marginBottom:'.1rem' }}>{tipClinic.name}</div>
            <div style={{ fontSize:'.62rem', color:'var(--amethyst)', marginBottom:'.35rem' }}>{tipClinic.spec}</div>
            <div style={{ color:'#f59e0b', fontSize:'.67rem', letterSpacing:1, marginBottom:'.08rem' }}>{'★'.repeat(Math.round(tipClinic.rating))}{'☆'.repeat(5-Math.round(tipClinic.rating))}</div>
            <div style={{ fontSize:'.63rem', color:'rgba(255,255,255,.5)', marginBottom:'.4rem' }}>{tipClinic.rating} · {tipClinic.rc.toLocaleString()} reviews · {tipClinic.acc?'✓ Accepting':'Waitlist'}</div>
            <button onClick={()=>{ setSelId(tipClinic.id); setDet(true); setTipClinic(null); }} style={{ width:'100%', padding:'.34rem', borderRadius:6, border:'none', cursor:'pointer', background:'linear-gradient(135deg,var(--violet),var(--amethyst))', color:'var(--white)', fontFamily:"'DM Sans',sans-serif", fontSize:'.67rem', fontWeight:500 }}>View &amp; Book →</button>
          </div>
        )}

        {/* Detail panel */}
        <div className={`det${detOpen?' open':''}`}>
          <div onClick={()=>setDet(false)} style={{ position:'absolute', top:'.85rem', right:'.85rem', width:26, height:26, borderRadius:'50%', background:'rgba(255,255,255,.06)', border:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', fontSize:'.72rem', zIndex:1 }}>✕</div>
          {selClinic && (
            <div>
              <div style={{ padding:'1.6rem 1.3rem 1rem', borderBottom:'1px solid var(--border)' }}>
                <div style={{ width:44, height:44, borderRadius:12, background:'linear-gradient(135deg,#2d1a5c,var(--violet))', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.2rem', marginBottom:'.82rem' }}>{selClinic.icon}</div>
                <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.05rem', fontWeight:700, marginBottom:'.18rem' }}>{selClinic.name}</div>
                <div style={{ fontSize:'.72rem', color:'var(--amethyst)', marginBottom:'.6rem' }}>{selClinic.spec}</div>
                <div style={{ display:'flex', alignItems:'center', gap:'.6rem', marginBottom:'.6rem' }}>
                  <div style={{ display:'flex', gap:2 }}>{starsH(selClinic.rating)}</div>
                  <span style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.05rem', fontWeight:700 }}>{selClinic.rating}</span>
                  <span style={{ fontSize:'.65rem', color:'var(--muted)' }}>{selClinic.rc.toLocaleString()} reviews</span>
                </div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:'.3rem' }}>
                  <span className={`chip chip-${selClinic.acc?'g':'r'}`}>{selClinic.acc?'✓ Accepting':'Waitlist'}</span>
                  <span className={`chip chip-${selClinic.open?'g':'r'}`}>{selClinic.open?'● Open':'● Closed'}</span>
                  <span className="chip chip-y">⏱ {selClinic.wait}d wait</span>
                </div>
              </div>
              {/* Info */}
              <div style={{ padding:'.9rem 1.3rem', borderBottom:'1px solid var(--border)' }}>
                <div style={{ fontSize:'.56rem', fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--muted)', marginBottom:'.6rem' }}>Clinic Info</div>
                {[[' 📍',selClinic.addr],['📞',selClinic.phone],['🕐',selClinic.hours],['🌐',selClinic.langs.join(' · ')]].map(([ico,val])=>(
                  <div key={ico} style={{ display:'flex', alignItems:'flex-start', gap:'.55rem', marginBottom:'.45rem', fontSize:'.74rem', color:'var(--dim)' }}>
                    <span style={{ width:17, textAlign:'center', fontSize:'.78rem', flexShrink:0, marginTop:'.04rem' }}>{ico}</span>{val}
                  </div>
                ))}
              </div>
              {/* Slots */}
              <div style={{ padding:'.9rem 1.3rem', borderBottom:'1px solid var(--border)' }}>
                <div style={{ fontSize:'.56rem', fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--muted)', marginBottom:'.6rem' }}>Next Available Slots</div>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'.35rem' }}>
                  {selClinic.slots.map((s,i)=>(
                    <div key={i} onClick={()=>setSelSlot(s)} style={{ padding:'.4rem .3rem', borderRadius:7, textAlign:'center', fontSize:'.64rem', fontWeight:500, cursor:'pointer', border:`1px solid ${selSlot===s?'var(--bh)':'var(--border)'}`, background: selSlot===s?'rgba(109,40,217,.22)':'rgba(255,255,255,.02)', color: selSlot===s?'var(--white)':'var(--dim)', transition:'all .2s' }}>
                      <span style={{ fontSize:'.52rem', color: selSlot===s?'var(--lavender)':'var(--muted)', display:'block' }}>{s.d}</span>{s.t}
                    </div>
                  ))}
                </div>
              </div>
              {/* Reviews */}
              <div style={{ padding:'.9rem 1.3rem', borderBottom:'1px solid var(--border)' }}>
                <div style={{ fontSize:'.56rem', fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--muted)', marginBottom:'.6rem' }}>Patient Reviews</div>
                {selClinic.reviews.map((r,i)=>(
                  <div key={i} style={{ background:'rgba(255,255,255,.025)', border:'1px solid rgba(255,255,255,.05)', borderRadius:9, padding:'.75rem', marginBottom:'.55rem' }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'.3rem' }}>
                      <div><span style={{ fontSize:'.72rem', fontWeight:600 }}>{r.a}</span> <span style={{ fontSize:'.56rem', color:'var(--amethyst)' }}>· {r.l}</span></div>
                      <span style={{ color:'#f59e0b', fontSize:'.6rem' }}>{'★'.repeat(r.s)}</span>
                    </div>
                    <div style={{ fontSize:'.7rem', color:'var(--dim)', lineHeight:1.6 }}>"{r.t}"</div>
                    <div style={{ fontSize:'.58rem', color:'var(--muted)', marginTop:'.28rem' }}>{r.d}</div>
                  </div>
                ))}
              </div>
              {/* Book CTA */}
              <div style={{ padding:'1rem 1.3rem' }}>
                <button className="mcta" onClick={()=>openModal('clinicBook',{clinic:selClinic})}>Book Appointment →</button>
                <div style={{ fontSize:'.62rem', color:'var(--muted)', textAlign:'center', marginTop:'.5rem' }}>🌐 Reminders in your language · PHIPA compliant</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
