// src/components/Views.jsx  — all remaining views in one file
import { useState, useEffect } from 'react';
import { useApp } from '../hooks/useApp';

/* ═══════════════════════════════════════════════
   HOME
═══════════════════════════════════════════════ */
export function HomeView() {
  const { go } = useApp();
  const [counts, setCounts] = useState([0, 0, 0, 0]);

  useEffect(() => {
    const targets = [10, 94, 12, 88];
    const dur     = [1200, 1400, 1000, 1500];
    targets.forEach((to, i) => {
      let start = null;
      const step = (ts) => {
        if (!start) start = ts;
        const p = Math.min((ts - start) / dur[i], 1);
        const ease = 1 - Math.pow(1 - p, 3);
        setCounts(c => { const n=[...c]; n[i]=Math.round(ease*to); return n; });
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }, []);

  const features = [
    ['📊','Patient Overview','Stats, upcoming appointments, care journey, and quick actions in one view.','p-overview'],
    ['🧭','Care Journey','5-step visual pathway tracking every milestone from intake to treatment.','p-journey'],
    ['🗺️','Clinic Finder + Map','Interactive GTA map with 12 clinics, language filters, and same-day booking.','find-care'],
    ['🔁','Referral Tracker','Real-time progress bars on every specialist referral, with language reminders.','p-referrals'],
    ['💬','Personal Navigator','Fatima speaks your language and coordinates every booking and reminder.','p-navigator'],
    ['🏥','Provider Dashboard','Smart scheduling, risk scoring, cancellation recovery, multilingual reminders.','prov-overview'],
    ['🌐','AI Translation','Real-time medical translation across 23 languages using Cohere's medical-grade model.','ai-translation'],
    ['🎙','Voice Recorder','Doctor–patient transcription with speaker diarization and AI clinical insights.','ai-recorder'],
    ['🧬','CDISC Mapping','AI-powered EHR extraction to CDISC SDTM standards with Claude compliance review.','ai-cdisc'],
  ];

  const heroStats = [
    [counts[0]+'+','Languages Supported'],
    [counts[1]+'%','Attendance Rate'],
    [counts[2],'GTA Clinics'],
    [counts[3]+'%','Referral Completion'],
  ];

  return (
    <div className="content fade-up">
      {/* Hero */}
      <div style={{ background:'linear-gradient(135deg,rgba(109,40,217,.12),rgba(139,92,246,.05))', border:'1px solid var(--border)', borderRadius:16, padding:'2rem', marginBottom:'1.2rem', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:-60, right:-60, width:200, height:200, background:'radial-gradient(circle,rgba(139,92,246,.15),transparent 70%)', pointerEvents:'none' }}/>
        <div style={{ fontSize:'.62rem', fontWeight:600, letterSpacing:'.14em', textTransform:'uppercase', color:'var(--amethyst)', marginBottom:'.75rem' }}>CareCompass · GTA Healthcare Platform</div>
        <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'2rem', fontWeight:700, lineHeight:1.22, letterSpacing:'-.02em', marginBottom:'.75rem' }}>
          Your health journey,<br/><em style={{ fontStyle:'italic', background:'linear-gradient(135deg,var(--lavender),var(--amethyst))', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>guided in your language.</em>
        </div>
        <div style={{ fontSize:'.82rem', color:'var(--dim)', lineHeight:1.7, maxWidth:560, marginBottom:'1.25rem' }}>
          Multilingual intake, smart matching, and end-to-end referral tracking for newcomers, seniors, and multicultural families across the Greater Toronto Area.
        </div>
        <div style={{ display:'flex', gap:'.65rem', flexWrap:'wrap', marginBottom:'1.5rem' }}>
          <button className="btn btn-p" onClick={()=>go('p-overview')}>🧭 Patient Dashboard</button>
          <button className="btn btn-g" onClick={()=>go('find-care')}>🗺️ Find Care Near Me</button>
          <button className="btn btn-g" onClick={()=>go('prov-overview')}>🏥 Provider Portal</button>
        </div>
        <div style={{ display:'flex', gap:'2.5rem', flexWrap:'wrap' }}>
          {heroStats.map(([n,l])=>(
            <div key={l}><div style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.5rem', fontWeight:700 }}>{n}</div><div style={{ fontSize:'.62rem', color:'var(--muted)', marginTop:'.1rem' }}>{l}</div></div>
          ))}
        </div>
      </div>

      {/* Feature grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'.85rem' }}>
        {features.map(([ico,title,desc,id])=>(
          <div key={id} onClick={()=>go(id)} style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:13, padding:'1.1rem', cursor:'pointer', transition:'all .22s', position:'relative', overflow:'hidden' }}
            onMouseEnter={e=>{ e.currentTarget.style.borderColor='var(--bh)'; e.currentTarget.style.transform='translateY(-2px)'; e.currentTarget.style.boxShadow='0 8px 24px rgba(0,0,0,.25)'; }}
            onMouseLeave={e=>{ e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.transform=''; e.currentTarget.style.boxShadow=''; }}>
            <div style={{ fontSize:'1.4rem', marginBottom:'.65rem' }}>{ico}</div>
            <div style={{ fontSize:'.83rem', fontWeight:600, marginBottom:'.3rem' }}>{title}</div>
            <div style={{ fontSize:'.7rem', color:'var(--muted)', lineHeight:1.6 }}>{desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PATIENT JOURNEY
═══════════════════════════════════════════════ */
export function PatientJourney() {
  const { go, openModal } = useApp();
  const [expanded, setExpanded] = useState({});

  const steps = [
    { dot:'done', title:'Initial Intake Complete',   detail:'Multilingual intake form submitted in Igbo + English. All health information securely stored.', chip:'cg', chipLabel:'Completed', date:'Nov 28' },
    { dot:'done', title:'Family Doctor Matched',     detail:'Matched with Dr. Adeyemi at Scarborough Health Network — Igbo-speaking, 1.2km away.', chip:'cg', chipLabel:'Completed', date:'Dec 1' },
    { dot:'done', title:'Blood Work Ordered',        detail:'LifeLabs Scarborough. CBC, lipid panel, HbA1c. Results received Dec 10 and shared with Dr. Adeyemi.', chip:'cg', chipLabel:'Completed', date:'Dec 5' },
    { dot:'now',  title:'Cardiology Consultation',  detail:'Dr. Patel at Mount Sinai confirmed Dec 18 at 10:30 AM. Igbo reminder will be sent Dec 17 at 8 AM.', chip:'cv', chipLabel:'Upcoming · Dec 18, 10:30 AM', date:'', extra:true },
    { dot:'pend', title:'Treatment Plan Review',    detail:'Navigator Fatima will follow up after specialist visit to confirm next steps.', chip:'cgr', chipLabel:'Pending', date:'' },
  ];

  return (
    <div className="content fade-up">
      <div className="g32">
        <div className="card">
          <div className="ch"><div><div className="ch-title">🧭 Cardiology Care Journey</div><div className="ch-sub">Full end-to-end pathway</div></div><span className="chip chip-g">75% complete</span></div>
          {steps.map((s, i) => (
            <div key={i} onClick={()=>setExpanded(e=>({...e,[i]:!e[i]}))} style={{ display:'flex', gap:'.8rem', padding:'.75rem 1.2rem', cursor:'pointer', transition:'background .2s' }}>
              <div style={{ display:'flex', flexDirection:'column', alignItems:'center', flexShrink:0 }}>
                <div style={{ width:26, height:26, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.72rem', fontWeight:700, flexShrink:0, border:'2px solid',
                  background: s.dot==='done'?'rgba(16,185,129,.15)':s.dot==='now'?'rgba(109,40,217,.2)':'rgba(255,255,255,.04)',
                  borderColor: s.dot==='done'?'var(--green)':s.dot==='now'?'var(--amethyst)':'rgba(255,255,255,.12)',
                  color: s.dot==='done'?'var(--green)':s.dot==='now'?'var(--amethyst)':'var(--muted)',
                  animation: s.dot==='now'?'pulse-j 2s infinite':undefined,
                }}>{s.dot==='done'?'✓':s.dot==='now'?'▶':(i+1)}</div>
                {i<4&&<div style={{ width:2, flex:1, minHeight:20, background:'linear-gradient(var(--border),transparent)', margin:'.18rem 0' }}/>}
              </div>
              <div style={{ flex:1, paddingTop:'.22rem' }}>
                <div style={{ fontSize:'.82rem', fontWeight:600, marginBottom:'.2rem' }}>{s.title}</div>
                <div style={{ fontSize:'.72rem', color:'var(--dim)', lineHeight:1.6, marginBottom:'.4rem' }}>{s.detail}</div>
                <div style={{ display:'flex', alignItems:'center', gap:'.55rem' }}>
                  <span className={`chip chip-${s.chip.replace('c','')}`}>{s.chipLabel}</span>
                  {s.date&&<span style={{ fontSize:'.62rem', color:'var(--muted)' }}>{s.date}</span>}
                </div>
                {s.extra && expanded[i] && (
                  <div style={{ marginTop:'.7rem', padding:'.75rem', background:'rgba(109,40,217,.08)', borderRadius:9, border:'1px solid rgba(139,92,246,.15)', fontSize:'.74rem', color:'var(--dim)', lineHeight:1.7 }}>
                    📍 <b>Location:</b> 600 University Ave, Toronto<br/>
                    🌐 <b>Language:</b> Igbo interpreter confirmed<br/>
                    📄 <b>Documents required:</b> Blood work results (ready), OHIP card<br/>
                    <button className="btn btn-p" style={{ marginTop:'.6rem', fontSize:'.7rem' }} onClick={e=>{e.stopPropagation();openModal('bookAppt');}}>Reschedule if needed</button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <div className="col">
          <div className="card"><div className="ch"><div className="ch-title">📊 Progress</div></div>
            <div className="cb">
              <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'2.2rem', fontWeight:900 }}>75%</div>
              <div style={{ fontSize:'.7rem', color:'var(--muted)', marginBottom:'.85rem' }}>4 of 5 steps complete</div>
              <div className="pbar" style={{ height:5 }}><div className="pfill" style={{ width:'75%', height:5 }}/></div>
            </div>
          </div>
          <div className="card"><div className="ch"><div className="ch-title">📄 Documents</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.4rem' }}>
              {[['📄 Intake Form (Igbo/En)','✓ Submitted'],['🩸 Blood Work Results','✓ Received'],['💌 Cardiology Referral Letter','✓ Sent']].map(([doc,st])=>(
                <div key={doc} style={{ display:'flex', alignItems:'center', gap:'.6rem', fontSize:'.76rem', padding:'.58rem', borderRadius:8, background:'rgba(255,255,255,.025)', border:'1px solid var(--border)' }}>
                  {doc}<span style={{ marginLeft:'auto', fontSize:'.58rem', color:'var(--green)' }}>{st}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card"><div className="ch"><div className="ch-title">⚡ Actions</div></div>
            <div className="cb">
              <button className="qa" onClick={()=>openModal('bookAppt')}><span className="qa-ico">📅</span>Book next appointment<span className="qa-arr">›</span></button>
              <button className="qa" onClick={()=>go('p-navigator')}><span className="qa-ico">💬</span>Ask Fatima a question<span className="qa-arr">›</span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PATIENT APPOINTMENTS
═══════════════════════════════════════════════ */
export function PatientAppointments() {
  const { go, openModal, toast } = useApp();
  return (
    <div className="content fade-up">
      <div className="g32">
        <div className="card">
          <div className="ch"><div><div className="ch-title">📅 Upcoming Appointments</div></div><button className="btn btn-p" style={{ fontSize:'.7rem' }} onClick={()=>openModal('bookAppt')}>+ Book New</button></div>
          <div className="cb">
            {[{day:'18',mo:'Dec',name:'Dr. Patel — Cardiology',detail:'10:30 AM · Mount Sinai · 600 University Ave',lang:'🌐 Igbo reminder scheduled for Dec 17',chip:'cg',chipLabel:'Confirmed',action:'Cancel',actionFn:()=>toast('Cancelled','Dr. Patel Dec 18 cancelled · Navigator notified','❌')},
              {day:'22',mo:'Dec',name:'Dr. Adeyemi — Follow-up',detail:'2:00 PM · Scarborough Health Network',lang:'🌐 Igbo · English',chip:'cv',chipLabel:'Scheduled',action:'Remind',actionFn:()=>toast('Reminder sent','Igbo SMS reminder scheduled','📱')}].map((a,i)=>(
              <div key={i} style={{ display:'flex', alignItems:'center', gap:'.85rem', padding:'.85rem 0', borderBottom: i===0?'1px solid var(--border)':'none' }}>
                <div style={{ width:38, textAlign:'center', flexShrink:0 }}>
                  <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.3rem', fontWeight:700, lineHeight:1.1 }}>{a.day}</div>
                  <div style={{ fontSize:'.6rem', color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.06em' }}>{a.mo}</div>
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:'.8rem', fontWeight:500 }}>{a.name}</div>
                  <div style={{ fontSize:'.68rem', color:'var(--muted)', marginTop:'.1rem' }}>{a.detail}</div>
                  <div style={{ fontSize:'.65rem', color:'var(--amethyst)', marginTop:'.15rem' }}>{a.lang}</div>
                </div>
                <div style={{ display:'flex', flexDirection:'column', gap:'.28rem', alignItems:'flex-end', flexShrink:0 }}>
                  <span className={`chip chip-${a.chip.replace('c','')}`}>{a.chipLabel}</span>
                  <button className="btn btn-g" style={{ fontSize:'.67rem', padding:'.3rem .65rem' }} onClick={a.actionFn}>{a.action}</button>
                </div>
              </div>
            ))}
          </div>
          <div className="ch" style={{ borderTop:'1px solid var(--border)' }}><div className="ch-title">📁 Past Appointments</div></div>
          <div className="cb">
            {[{day:'5',mo:'Dec',name:'LifeLabs — Blood Work',detail:'8:00 AM · Scarborough LifeLabs'},{day:'1',mo:'Dec',name:'Dr. Adeyemi — Initial Visit',detail:'9:30 AM · Scarborough Health Network'}].map((a,i)=>(
              <div key={i} style={{ display:'flex', alignItems:'center', gap:'.85rem', padding:'.85rem 0', borderBottom: i===0?'1px solid var(--border)':'none' }}>
                <div style={{ width:38, textAlign:'center', flexShrink:0 }}>
                  <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'1.3rem', fontWeight:700, lineHeight:1.1 }}>{a.day}</div>
                  <div style={{ fontSize:'.6rem', color:'var(--muted)', textTransform:'uppercase', letterSpacing:'.06em' }}>{a.mo}</div>
                </div>
                <div style={{ flex:1 }}><div style={{ fontSize:'.8rem', fontWeight:500 }}>{a.name}</div><div style={{ fontSize:'.68rem', color:'var(--muted)', marginTop:'.1rem' }}>{a.detail}</div></div>
                <span className="chip chip-gr">Completed</span>
              </div>
            ))}
          </div>
        </div>
        <div className="col">
          <div className="card"><div className="ch"><div className="ch-title">⚡ Book Appointment</div></div>
            <div className="cb">
              {[['🏥','With my family doctor',()=>openModal('bookAppt')],['🗺️','Find a new specialist',()=>go('find-care')],['💻','Virtual consultation',()=>openModal('bookAppt')]].map(([ico,lbl,fn],i)=>(
                <button key={i} className="qa" onClick={fn}><span className="qa-ico">{ico}</span>{lbl}<span className="qa-arr">›</span></button>
              ))}
            </div>
          </div>
          <div className="card"><div className="ch"><div className="ch-title">🔔 Reminders</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.4rem' }}>
              {['📱 Dec 17 — Igbo SMS for Dec 18 cardiology','📧 Dec 21 — Email reminder for Dec 22 follow-up'].map(r=>(
                <div key={r} style={{ padding:'.65rem', borderRadius:9, background:'rgba(109,40,217,.09)', border:'1px solid rgba(139,92,246,.18)', fontSize:'.76rem' }}>{r}</div>
              ))}
              <button className="qa" onClick={()=>toast('Preference saved','Reminder channel updated to SMS + Email','🔔')}><span className="qa-ico">⚙️</span>Edit reminder settings<span className="qa-arr">›</span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PATIENT REFERRALS
═══════════════════════════════════════════════ */
export function PatientReferrals() {
  const { go, toast } = useApp();
  const refs = [
    {ico:'❤️',title:'Cardiology — Dr. Patel, Mount Sinai',detail:'Routine · Referred by Dr. Adeyemi · Dec 1',chip:'g',chipLabel:'Booked · Dec 18',steps:'3/4',w:'75%',btnLabel:'Details',btnCls:'btn-g',btnFn:()=>toast('Referral details','Cardiology referral — Dr. Patel · Active','❤️')},
    {ico:'🩸',title:'Hematology — LifeLabs Scarborough',detail:'Routine · Blood work complete · Results Dec 10',chip:'g',chipLabel:'Completed',steps:'4/4',w:'100%',btnLabel:'Results',btnCls:'btn-g',btnFn:()=>toast('Results ready','Blood work results available · Dec 10','🩸')},
    {ico:'🦴',title:'Orthopaedics — Sunnybrook Health Sciences',detail:'Semi-urgent · Referred Dec 8 · Awaiting booking',chip:'y',chipLabel:'Pending',steps:'1/4',w:'20%',barColor:'linear-gradient(90deg,#d97706,var(--yellow))',btnLabel:'Book Now →',btnCls:'btn-p',btnFn:()=>go('find-care')},
  ];
  return (
    <div className="content fade-up">
      <div className="card gap">
        <div className="ch"><div><div className="ch-title">🔁 All Referrals</div><div className="ch-sub">3 active · 1 pending booking</div></div></div>
        {refs.map((r,i)=>(
          <div key={i} style={{ display:'flex', alignItems:'center', gap:'.7rem', padding:'.82rem 1.2rem', borderBottom: i<2?'1px solid var(--border)':'none' }}>
            <div style={{ fontSize:'1.1rem', flexShrink:0, width:28, textAlign:'center' }}>{r.ico}</div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:'.78rem', fontWeight:500 }}>{r.title}</div>
              <div style={{ fontSize:'.65rem', color:'var(--muted)', marginTop:'.1rem' }}>{r.detail}</div>
              <div style={{ display:'flex', alignItems:'center', gap:'.5rem', marginTop:'.32rem' }}>
                <span className={`chip chip-${r.chip}`}>{r.chipLabel}</span>
                <span style={{ fontSize:'.6rem', color:'var(--muted)' }}>{r.steps} steps</span>
              </div>
              <div className="pbar"><div className="pfill" style={{ width:r.w, background:r.barColor||undefined }}/></div>
            </div>
            <button className={`btn ${r.btnCls}`} style={{ marginLeft:'auto', flexShrink:0, fontSize:'.69rem' }} onClick={r.btnFn}>{r.btnLabel}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PATIENT RECORDS
═══════════════════════════════════════════════ */
export function PatientRecords() {
  const { toast } = useApp();
  return (
    <div className="content fade-up">
      <div className="g2">
        <div className="card">
          <div className="ch"><div className="ch-title">📋 Health Profile</div><button className="btn btn-g" style={{ fontSize:'.69rem' }} onClick={()=>toast('Edit mode','Profile editing available in full product','📋')}>Edit</button></div>
          <div className="cb">
            {[['CONDITIONS',['Hypertension','Iron-deficiency Anaemia'],'hcond'],['MEDICATIONS',['Lisinopril 10mg','Iron supplements 65mg'],'hmed'],['ALLERGIES',['⚠ Penicillin','⚠ Sulfa drugs'],'hallergy']].map(([label,items,cls])=>(
              <div key={label}>
                <div style={{ fontSize:'.58rem', fontWeight:600, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--muted)', marginBottom:'.42rem', marginTop: label!=='CONDITIONS'?'.85rem':0 }}>{label}</div>
                <div style={{ display:'flex', flexWrap:'wrap', marginBottom: label==='ALLERGIES'?0:'.4rem' }}>
                  {items.map(item=><span key={item} className={`htag ${cls}`}>{item}</span>)}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="col">
          <div className="card"><div className="ch"><div className="ch-title">🆔 OHIP</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.45rem', fontSize:'.78rem' }}>
              {[['Card #','****-****-**42'],['Expiry','March 2026'],['Version','XP']].map(([l,v])=>(
                <div key={l} style={{ display:'flex', justifyContent:'space-between' }}><span style={{ color:'var(--muted)' }}>{l}</span><span style={{ fontFamily: l==='Card #'?"'DM Mono',monospace":'inherit' }}>{v}</span></div>
              ))}
            </div>
          </div>
          <div className="card"><div className="ch"><div className="ch-title">🆘 Emergency Contact</div></div>
            <div className="cb" style={{ fontSize:'.78rem', display:'flex', flexDirection:'column', gap:'.35rem' }}>
              {[['Name','Chukwuemeka Nwosu'],['Relation','Spouse'],['Phone','(416) 555-0187']].map(([l,v])=>(
                <div key={l}><span style={{ color:'var(--muted)' }}>{l}: </span>{v}</div>
              ))}
            </div>
          </div>
          <div className="card"><div className="ch"><div className="ch-title">📄 Documents</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.38rem', fontSize:'.76rem' }}>
              {['📄 Intake Form (Igbo/En)','🩸 Blood Work Dec 10'].map(d=>(
                <div key={d} style={{ display:'flex', alignItems:'center', gap:'.58rem', padding:'.55rem', borderRadius:8, background:'rgba(255,255,255,.025)', border:'1px solid var(--border)' }}>
                  {d}<span style={{ marginLeft:'auto', fontSize:'.58rem', color:'var(--green)' }}>✓</span>
                </div>
              ))}
              <button className="qa" onClick={()=>toast('Download started','Downloading all records as PDF','📄')}><span className="qa-ico">⬇️</span>Download all records<span className="qa-arr">›</span></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   PROVIDER OVERVIEW
═══════════════════════════════════════════════ */
export function ProviderOverview() {
  const { openModal, toast } = useApp();
  const [bars, setBars] = useState(false);
  useEffect(()=>{ const t=setTimeout(()=>setBars(true),120); return()=>clearTimeout(t); },[]);

  const schedule = [
    {time:'9:00 AM',init:'AN',name:'Amara Nwosu',lang:'🌐 Igbo · English',type:'Follow-up',status:'cg',statusLabel:'✓ CC-Ready',risk:'g',riskLabel:'● Low',btn:'View Chart',btnFn:()=>toast('Chart opened','Amara Nwosu · Igbo reminders sent','📋')},
    {time:'9:30 AM',init:'MK',name:'Mohammed Khan',lang:'🌐 Urdu · English',type:'Initial',status:'cy',statusLabel:'⏳ Forms Pending',risk:'y',riskLabel:'● Medium',btn:'Remind',btnFn:()=>toast('Reminder sent','Urdu reminder dispatched','📱')},
    {time:'10:30 AM',init:'LC',name:'Li Chen',lang:'🌐 Mandarin',type:'Blood Work',status:'cg',statusLabel:'✓ CC-Ready',risk:'g',riskLabel:'● Low',btn:'View Chart',btnFn:()=>toast('Chart opened','Li Chen · Mandarin reminders set','📋')},
    {time:'11:00 AM',init:'PR',name:'Patricia Reyes',lang:'🌐 Tagalog · Spanish',type:'Specialist',status:'cr',statusLabel:'🔴 High Risk',risk:'r',riskLabel:'● High',btn:'Review Risk',btnFn:()=>openModal('riskAlert'),urg:true},
    {time:'2:00 PM',init:'DS',name:'Daniel Singh',lang:'🌐 Punjabi · English',type:'Follow-up',status:'cg',statusLabel:'✓ CC-Ready',risk:'g',riskLabel:'● Low',btn:'View Chart',btnFn:()=>toast('Chart opened','Daniel Singh','📋')},
    {time:'3:00 PM',init:'SK',name:'Sunita Kaur',lang:'🌐 Hindi · Punjabi',type:'Virtual',status:'cy',statusLabel:'⏳ Intake Pending',risk:'y',riskLabel:'● Medium',btn:'Send Intake',btnFn:()=>toast('Intake sent','Hindi intake reminder dispatched','📱')},
  ];

  const chartData = [88,92,95,91,97,78,0];
  const mbarRows = [['Attendance','fill-g','94%',94],['Referrals Done','fill-b','88%',88],['No-Show Rate','fill-r','6%',6],['Slot Recovery','fill-y','78%',78]];
  const langRows = [['Igbo',28],['Urdu',22],['Mandarin',18],['Tagalog',14],['Hindi',11]];

  return (
    <div className="content fade-up">
      <div className="g5">
        {[[' ✅','ig','94%','Attendance Rate','▲4%','dg'],[' ⚠️','ir','2','High-Risk Appts','2 today','dr'],[' 🔁','iy','88%','Referral Completion','3 pending','dy'],[' ⚡','it','12','Slots Recovered','Auto','dg'],[' 🌐','iv','8','Patients Today','4 langs','dg']].map(([ico,cls,num,lbl,delta,dc],i)=>(
          <div key={i} className="sc">
            <div className="sc-top"><div className={`sc-ico ${cls}`}>{ico.trim()}</div><span className={`sc-delta ${dc}`}>{delta}</span></div>
            <div className="sc-num">{num}</div><div className="sc-lbl">{lbl}</div>
          </div>
        ))}
      </div>

      <div className="card gap">
        <div className="ch"><div><div className="ch-title">📅 Today's Schedule — December 13</div><div className="ch-sub">8 appointments · 2 CC-Ready · 1 high risk flagged</div></div>
          <div style={{ display:'flex', gap:'.38rem' }}>
            <button className="btn btn-g" style={{ fontSize:'.69rem' }} onClick={()=>toast('Export ready','Schedule PDF exported','📄')}>Export</button>
            <button className="btn btn-p" style={{ fontSize:'.69rem' }} onClick={()=>openModal('fillSlot')}>+ Fill Slot</button>
          </div>
        </div>
        <div style={{ overflowX:'auto' }}>
          <table className="sch-tbl">
            <thead><tr><th>Time</th><th>Patient</th><th>Type</th><th>CC Status</th><th>Risk</th><th>Actions</th></tr></thead>
            <tbody>
              {schedule.map((s,i)=>{
                const grad = {AN:'linear-gradient(135deg,#4c1d95,#6d28d9)',MK:'linear-gradient(135deg,#1a3a1a,#166534)',LC:'linear-gradient(135deg,#1a1a3a,#1e40af)',PR:'linear-gradient(135deg,#3a1a1a,#7f1d1d)',DS:'linear-gradient(135deg,#1a2a3a,#0c4a6e)',SK:'linear-gradient(135deg,#2a1a3a,#6b21a8)'}[s.init];
                return (
                  <tr key={i} className={s.urg?'urg':''}>
                    <td style={{ fontFamily:"'DM Mono',monospace", fontSize:'.73rem', color:'var(--dim)', whiteSpace:'nowrap' }}>{s.time}</td>
                    <td><div style={{ display:'flex', alignItems:'center', gap:'.55rem' }}>
                      <div style={{ width:26, height:26, borderRadius:'50%', background:grad, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:"'Playfair Display',serif", fontSize:'.62rem', fontWeight:700, flexShrink:0, border:'1px solid rgba(255,255,255,.12)' }}>{s.init}</div>
                      <div><div style={{ fontSize:'.77rem', fontWeight:500 }}>{s.name}</div><div style={{ fontSize:'.6rem', color:'var(--amethyst)', marginTop:'.05rem' }}>{s.lang}</div></div>
                    </div></td>
                    <td style={{ fontSize:'.74rem', color:'var(--dim)' }}>{s.type}</td>
                    <td><span className={`chip chip-${s.status.replace('c','')}`}>{s.statusLabel}</span></td>
                    <td><span style={{ color:`var(--${s.risk})`, fontSize:'.74rem' }}>{s.riskLabel}</span></td>
                    <td><button className="btn btn-p" style={{ fontSize:'.67rem', padding:'.3rem .65rem' }} onClick={s.btnFn}>{s.btn}</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="g23">
        <div className="col">
          <div className="card">
            <div className="ch"><div><div className="ch-title">🔁 Referral Queue</div><div className="ch-sub">Sorted by urgency</div></div></div>
            {[{ico:'🏥',title:'Yemi Okafor → General Practice',detail:'Yoruba · St. Michael\'s · Chest pain workup',chip:'r',chipLabel:'Urgent',fn:()=>toast('Accepted','Yemi Okafor intake sent in Yoruba','✅')},
              {ico:'💊',title:'Hiroshi Tanaka → Med Review',detail:'Japanese · Self-referral · Diabetes mgmt',chip:'y',chipLabel:'Semi',fn:()=>toast('Accepted','Hiroshi intake sent in Japanese','✅')},
              {ico:'👁️',title:'Maria Costa → Annual Check-up',detail:'Portuguese · Community referral · Routine',chip:'gr',chipLabel:'Routine',fn:()=>toast('Scheduled','Maria Costa added to next slot','📅')}].map((r,i)=>(
              <div key={i} style={{ display:'flex', alignItems:'center', gap:'.7rem', padding:'.82rem 1.2rem', borderBottom: i<2?'1px solid var(--border)':'none' }}>
                <div style={{ fontSize:'1.1rem', flexShrink:0 }}>{r.ico}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:'.78rem', fontWeight:500 }}>{r.title}</div>
                  <div style={{ fontSize:'.65rem', color:'var(--muted)', marginTop:'.1rem' }}>{r.detail}</div>
                </div>
                <span className={`chip chip-${r.chip}`} style={{ flexShrink:0 }}>{r.chipLabel}</span>
                <button className="btn btn-p" style={{ marginLeft:'.4rem', flexShrink:0, fontSize:'.67rem', padding:'.3rem .65rem' }} onClick={r.fn}>Accept</button>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="ch"><div className="ch-title">📈 Attendance This Week</div><span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.68rem', color:'var(--green)' }}>94% avg</span></div>
            <div style={{ display:'flex', alignItems:'flex-end', gap:4, padding:'0 1.2rem', height:56 }}>
              {chartData.map((v,i)=><div key={i} style={{ flex:1, borderRadius:'3px 3px 0 0', background:'linear-gradient(180deg,var(--amethyst),rgba(109,40,217,.3))', height:bars?`${v?Math.round(v/100*48):2}px`:'2px', opacity:v?1:.2, transition:`height ${0.5+i*0.08}s cubic-bezier(.4,0,.2,1)`, minHeight:2 }}/>)}
            </div>
            <div style={{ display:'flex', justifyContent:'space-around', padding:'0 1.2rem .75rem', fontSize:'.58rem', color:'var(--muted)' }}>
              {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d=><span key={d}>{d}</span>)}
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card">
            <div className="ch"><div className="ch-title">📊 Clinic Performance</div></div>
            <div className="cb">
              {mbarRows.map(([lbl,cls,val,w])=>(
                <div key={lbl} style={{ display:'flex', alignItems:'center', gap:'.65rem', marginBottom:'.62rem' }}>
                  <span style={{ fontSize:'.68rem', color:'var(--dim)', width:90, flexShrink:0 }}>{lbl}</span>
                  <div style={{ flex:1, background:'rgba(255,255,255,.06)', borderRadius:100, height:5, overflow:'hidden' }}>
                    <div className={`pfill ${cls}`} style={{ width: bars?`${w}%`:'0%', height:'100%', transition:`width 1.2s cubic-bezier(.4,0,.2,1)` }}/>
                  </div>
                  <span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.68rem', color:'var(--white)', width:30, textAlign:'right', flexShrink:0 }}>{val}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="ch"><div><div className="ch-title">⚡ Smart Recovery</div><div className="ch-sub">Auto-matched waitlisted patients</div></div></div>
            <div style={{ padding:'.55rem .85rem' }}>
              {[['11:00 AM','Kwame Asante','🌐 Twi · Waitlisted 3 days'],['3:30 PM','Rosa Mendez','🌐 Spanish · Waitlisted 5 days']].map(([time,name,lang],i)=>(
                <div key={i} onClick={()=>toast('Slot filled!',`${name} booked · reminder sent`,'⚡')} style={{ display:'flex', alignItems:'center', gap:'.65rem', padding:'.65rem .75rem', borderRadius:9, cursor:'pointer', transition:'all .2s', border:'1px solid transparent', marginBottom:'.35rem' }}
                  onMouseEnter={e=>{ e.currentTarget.style.background='rgba(109,40,217,.15)'; e.currentTarget.style.borderColor='rgba(139,92,246,.2)'; }}
                  onMouseLeave={e=>{ e.currentTarget.style.background='transparent'; e.currentTarget.style.borderColor='transparent'; }}>
                  <span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.7rem', color:'var(--dim)', flexShrink:0, width:60 }}>{time}</span>
                  <div style={{ flex:1 }}><div style={{ fontSize:'.76rem', fontWeight:500 }}>{name}</div><div style={{ fontSize:'.6rem', color:'var(--muted)' }}>{lang}</div></div>
                  <span style={{ fontSize:'.68rem', color:'var(--amethyst)', fontWeight:600, transition:'color .18s' }}>Fill →</span>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="ch"><div className="ch-title">🌐 Patient Language Mix</div></div>
            <div className="cb">
              {langRows.map(([lang,pct])=>(
                <div key={lang} style={{ display:'flex', alignItems:'center', gap:'.6rem', marginBottom:'.55rem' }}>
                  <span style={{ fontSize:'.68rem', color:'var(--dim)', width:72, flexShrink:0 }}>{lang}</span>
                  <div style={{ flex:1, background:'rgba(255,255,255,.06)', borderRadius:100, height:4, overflow:'hidden' }}>
                    <div style={{ height:'100%', borderRadius:100, background:'linear-gradient(90deg,var(--violet),var(--amethyst))', width: bars?`${pct}%`:'0%', transition:`width 1.2s cubic-bezier(.4,0,.2,1)` }}/>
                  </div>
                  <span style={{ fontFamily:"'DM Mono',monospace", fontSize:'.65rem', color:'var(--muted)', width:28, textAlign:'right', flexShrink:0 }}>{pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════
   SETTINGS (stub)
═══════════════════════════════════════════════ */
export function SettingsView() {
  const { toast } = useApp();
  return (
    <div className="content fade-up">
      <div className="card" style={{ maxWidth:560 }}>
        <div className="ch"><div className="ch-title">⚙️ Settings</div></div>
        <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.7rem' }}>
          {['Preferred Language','Notification Channel','Reminder Timing','Theme'].map(s=>(
            <div key={s} className="mfield" style={{ margin:0 }}>
              <label className="mlbl">{s}</label>
              <select className="minput"><option>Default</option></select>
            </div>
          ))}
          <button className="btn btn-p" style={{ alignSelf:'flex-start' }} onClick={()=>toast('Settings saved','Preferences updated','⚙️')}>Save Changes</button>
        </div>
      </div>
    </div>
  );
}
