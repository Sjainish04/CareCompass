import { useState } from 'react';
import { useApp } from '../../hooks/useApp';
export default function AIKeysModal() {
  const { closeModal, toast, aiKeys, setAiKeys } = useApp();
  const [c, setC] = useState(aiKeys.cohere);
  const [a, setA] = useState(aiKeys.anthropic);
  const [showC, setShowC] = useState(false);
  const [showA, setShowA] = useState(false);
  return (
    <div className="modal-box" style={{ maxWidth:440 }}>
      <div className="mhd"><div className="mhd-ico">🔑</div><div><div className="mhd-name">AI Suite API Keys</div><div className="mhd-sub">Session-only · never stored to disk</div></div><button className="mclose" onClick={closeModal}>✕</button></div>
      <div className="mbody">
        <div className="mfield"><label className="mlbl">Cohere API Key — translation, EHR extraction, SDTM mapping</label>
          <div style={{ display:'flex', gap:'.45rem' }}><input className="minput" type={showC?'text':'password'} placeholder="co-..." value={c} onChange={e=>setC(e.target.value)} style={{ flex:1 }}/><button className="btn btn-g" style={{ fontSize:'.66rem', padding:'.38rem .6rem' }} onClick={()=>setShowC(s=>!s)}>👁</button></div></div>
        <div className="mfield"><label className="mlbl">Anthropic API Key — Claude clinical reasoning &amp; insights</label>
          <div style={{ display:'flex', gap:'.45rem' }}><input className="minput" type={showA?'text':'password'} placeholder="sk-ant-..." value={a} onChange={e=>setA(e.target.value)} style={{ flex:1 }}/><button className="btn btn-g" style={{ fontSize:'.66rem', padding:'.38rem .6rem' }} onClick={()=>setShowA(s=>!s)}>👁</button></div></div>
        <div style={{ fontSize:'.63rem', color:'rgba(255,255,255,.38)', marginBottom:'.85rem', lineHeight:1.65 }}>
          💡 dashboard.cohere.com &nbsp;|&nbsp; console.anthropic.com<br/>Without keys, all AI features show realistic demo responses.
        </div>
        <button className="mcta" onClick={() => { setAiKeys({ cohere:c, anthropic:a }); closeModal(); toast('Keys saved','Session-only — not persisted','🔑'); }}>Save Keys</button>
      </div>
    </div>
  );
}
