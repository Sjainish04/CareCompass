import { useApp } from '../../hooks/useApp';

export default function BookApptModal() {
  const { closeModal, toast } = useApp();
  return (
    <div className="modal-box">
      <div className="mhd">
        <div className="mhd-ico">📅</div>
        <div><div className="mhd-name">Book an Appointment</div><div className="mhd-sub">Navigator confirms within 2 hours</div></div>
        <button className="mclose" onClick={closeModal}>✕</button>
      </div>
      <div className="mbody">
        <span className="msec-lbl">Appointment Details</span>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.65rem' }}>
          <div className="mfield"><label className="mlbl">Type</label>
            <select className="minput"><option>Specialist Visit</option><option>Follow-up</option><option>Initial Consult</option><option>Virtual</option><option>Lab / Test</option></select>
          </div>
          <div className="mfield"><label className="mlbl">Preferred Language</label>
            <select className="minput"><option>Igbo</option><option>English</option><option>Urdu</option><option>Mandarin</option><option>Hindi</option></select>
          </div>
        </div>
        <div className="mfield"><label className="mlbl">Provider / Clinic (optional)</label><input className="minput" placeholder="e.g. Dr. Patel or Mount Sinai"/></div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'.65rem' }}>
          <div className="mfield"><label className="mlbl">Preferred Date</label><input className="minput" type="date"/></div>
          <div className="mfield"><label className="mlbl">Preferred Time</label><input className="minput" type="time"/></div>
        </div>
        <div className="mfield"><label className="mlbl">Notes for Navigator</label><input className="minput" placeholder="Any context to share…"/></div>
        <button className="mcta" onClick={() => { closeModal(); toast('Request sent!', 'Fatima will confirm within 2 hours', '📅'); }}>
          Request Appointment
        </button>
      </div>
    </div>
  );
}
