// src/components/ai/AICDISC.jsx
import { useState } from 'react';
import { useApp } from '../../hooks/useApp';
import { CDISC_DOMAINS, AI_PRED_DOMAINS, SAMPLE_EHR, DEMO_VARS } from '../../data';

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

const PIPELINE_STAGES = [
  { ico:'📄', name:'EHR Text Parsing',               done:'EHR parsed — ready for extraction' },
  { ico:'🧬', name:'Cohere: EHR Insight Extraction', done:'47 clinical entities extracted' },
  { ico:'🩻', name:'Aya Vision: X-Ray Analysis',     done:'Image analysis complete' },
  { ico:'🗂', name:'Cohere: SDTM Domain Prediction', done:'6 domains predicted: DM, VS, LB, CM, MH, AE' },
  { ico:'📊', name:'Cohere: CDISC Standards Mapping',done:'62 variables mapped across 6 domains' },
  { ico:'⚖',  name:'Claude: Compliance Evaluation',  done:'Compliance score: 91%' },
];

export function AICDISC() {
  const { aiKeys, toast } = useApp();
  const [step, setStep]           = useState(0);
  const [ehrText, setEhrText]     = useState('');
  const [xrayName, setXrayName]   = useState('');
  const [stageStatus, setStageStatus] = useState(PIPELINE_STAGES.map(() => 'idle'));
  const [aiOut, setAiOut]         = useState('');
  const [selDomains, setSelDomains] = useState(new Set(AI_PRED_DOMAINS));
  const [vars, setVars]           = useState([]);
  const [domFilter, setDomFilter] = useState('all');
  const [showAddRow, setShowAddRow] = useState(false);
  const [newRow, setNewRow]       = useState({ domain:'DM', variable:'', label:'', value:'' });
  const [review, setReview]       = useState('');
  const [reviewLoading, setReviewLoading] = useState(false);

  /* ── Step navigation ── */
  function jumpStep(n) { if (n <= step) setStep(n); }

  /* ── Step 0: Input ── */
  function renderStep0() {
    return (
      <div className="g2">
        <div>
          <div className="card gap">
            <div className="ch"><div><div className="ch-title">📄 EHR / Clinical Notes</div><div className="ch-sub">Paste free-text EHR, discharge summaries, or clinical notes</div></div></div>
            <div className="cb">
              <textarea className="inp" value={ehrText} onChange={e=>setEhrText(e.target.value)} style={{ minHeight:160, fontSize:'.72rem', lineHeight:1.7 }} placeholder="Paste patient EHR here…"/>
              <div style={{ display:'flex', gap:'.38rem', marginTop:'.5rem' }}>
                <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setEhrText(SAMPLE_EHR)}>📄 Sample EHR</button>
                <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setEhrText('')}>🗑 Clear</button>
              </div>
            </div>
          </div>
          <div className="card" style={{ marginTop:'1rem' }}>
            <div className="ch"><div><div className="ch-title">🩻 X-Ray / Medical Images</div><div className="ch-sub">Upload for Aya Vision AI analysis</div></div></div>
            <div className="cb">
              <div className="upload-z" onClick={()=>document.getElementById('xrInput').click()}>
                <div style={{ fontSize:'2rem', marginBottom:'.65rem' }}>{xrayName ? '✅' : '🩻'}</div>
                <div style={{ fontSize:'.85rem', fontWeight:600, marginBottom:'.3rem' }}>{xrayName || 'Drop X-ray or click to upload'}</div>
                <div style={{ fontSize:'.7rem', color:'var(--muted)' }}>JPEG · PNG · AI extracts radiological findings via Aya Vision</div>
              </div>
              <input id="xrInput" type="file" accept="image/*" style={{ display:'none' }} onChange={e=>{ if(e.target.files[0]) { setXrayName(e.target.files[0].name); toast('X-ray loaded', e.target.files[0].name, '🩻'); }}}/>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card">
            <div className="ch"><div className="ch-title">🎯 Pipeline Options</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.6rem' }}>
              <div><div style={{ fontSize:'.6rem', color:'var(--muted)', marginBottom:'.28rem' }}>Study Type</div>
                <select className="inp" style={{ fontSize:'.71rem' }}><option>Clinical Trial (CDISC SDTM)</option><option>Observational Study</option><option>Regulatory Submission</option><option>Patient Registry</option></select></div>
              <div><div style={{ fontSize:'.6rem', color:'var(--muted)', marginBottom:'.28rem' }}>SDTM Version</div>
                <select className="inp" style={{ fontSize:'.71rem' }}><option>SDTM v3.4 (Current)</option><option>SDTM v3.3</option><option>SDTM v3.2 (Legacy)</option></select></div>
              <label style={{ display:'flex', alignItems:'center', gap:'.5rem', fontSize:'.72rem', cursor:'pointer', color:'var(--dim)' }}><input type="checkbox" defaultChecked style={{ accentColor:'var(--amethyst)' }}/> Extract from EHR</label>
              <label style={{ display:'flex', alignItems:'center', gap:'.5rem', fontSize:'.72rem', cursor:'pointer', color:'var(--dim)' }}><input type="checkbox" style={{ accentColor:'var(--amethyst)' }}/> Include X-ray findings</label>
            </div>
          </div>
          <div className="card">
            <div className="ch"><div className="ch-title">🤖 AI Models</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.35rem' }}>
              {[['Cohere Command A','EHR extraction · SDTM prediction · mapping'],['Claude claude-sonnet-4-20250514','Clinical reasoning · compliance review'],['Cohere Aya Vision','X-ray image analysis']].map(([n,d])=>(
                <div key={n} style={{ padding:'.52rem', borderRadius:8, background:'rgba(255,255,255,.025)', border:'1px solid var(--border)', fontSize:'.7rem' }}>
                  <div style={{ color:'var(--lavender)', fontWeight:600, marginBottom:'.1rem' }}>{n}</div>
                  <div style={{ color:'var(--muted)' }}>{d}</div>
                </div>
              ))}
            </div>
          </div>
          <button className="btn btn-p" style={{ width:'100%', justifyContent:'center', padding:'.72rem', fontSize:'.8rem' }} onClick={runPipeline}>🚀 Run AI Pipeline →</button>
        </div>
      </div>
    );
  }

  /* ── Step 1: Pipeline running ── */
  async function runPipeline() {
    if (!ehrText.trim()) { toast('No EHR data','Click Sample EHR or paste notes first','⚠️'); return; }
    setStep(1);
    const statuses = PIPELINE_STAGES.map(() => 'idle');
    setStageStatus([...statuses]);

    for (let i = 0; i < PIPELINE_STAGES.length; i++) {
      statuses[i] = 'running';
      setStageStatus([...statuses]);
      await sleep(900 + Math.random() * 600);

      if (i === 1 && aiKeys.cohere) {
        try {
          const r = await fetch('https://api.cohere.com/v2/chat', { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${aiKeys.cohere}`}, body:JSON.stringify({ model:'command-a-03-2025', messages:[{role:'user',content:`Extract clinical data from this EHR as JSON: demographics, vitals, medications, diagnoses, labs, allergies, plan.\n\n${ehrText}`}], response_format:{type:'json_object'}, max_tokens:2000 }) });
          const d = await r.json();
          const raw = d.message?.content?.[0]?.text || '{}';
          try {
            const parsed = JSON.parse(raw.replace(/```json|```/g,'').trim());
            setAiOut('<b>Cohere extraction:</b><br>' + Object.keys(parsed).map(k=>`<b>${k}:</b> ${JSON.stringify(parsed[k]).substring(0,90)}`).join('<br>'));
          } catch { setAiOut('<b>Cohere:</b> ' + raw.substring(0,350)); }
        } catch {}
      }

      statuses[i] = 'done';
      setStageStatus([...statuses]);
    }

    setVars(DEMO_VARS.map(v => ({...v})));
    setTimeout(() => setStep(2), 600);
  }

  function renderStep1() {
    return (
      <div className="g32">
        <div>
          <div className="card gap">
            <div className="ch"><div><div className="ch-title">🤖 AI Extraction Pipeline</div><div className="ch-sub">{stageStatus.every(s=>s==='done')?'All 6 stages complete':'Running all stages…'}</div></div>
              <span className={`chip chip-${stageStatus.every(s=>s==='done')?'g':'y'}`}>{stageStatus.every(s=>s==='done')?'Complete':'Running'}</span>
            </div>
            <div className="cb">
              {PIPELINE_STAGES.map((s,i) => {
                const st = stageStatus[i];
                return (
                  <div key={i} className={`ps-row${st==='running'?' running':st==='done'?' done-s':''}`}>
                    <div className={`ps-ico${st==='running'?' running':st==='done'?' done-s':' idle'}`}>{s.ico}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:'.77rem', fontWeight:600, marginBottom:'.1rem' }}>{s.name}</div>
                      <div style={{ fontSize:'.63rem', color:'var(--muted)' }}>{st==='done' ? s.done : 'Queued'}</div>
                    </div>
                    <div>
                      {st==='running' && <div className="pipe-spin"/>}
                      {st==='done'    && <span className="chip chip-g">Done</span>}
                      {st==='idle'    && <span className="chip chip-gr">Queued</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div>
          <div className="card">
            <div className="ch"><div className="ch-title">📡 AI Output</div></div>
            <div className="cb" style={{ maxHeight:340, overflowY:'auto', minHeight:100, fontSize:'.71rem', color:'var(--muted)' }}>
              {aiOut ? <div className="ai-bub" dangerouslySetInnerHTML={{__html:aiOut}}/> : 'Pipeline running…'}
            </div>
          </div>
        </div>
      </div>
    );
  }

  /* ── Step 2: Domain selection ── */
  function toggleDomain(code) {
    setSelDomains(prev => {
      const next = new Set(prev);
      next.has(code) ? next.delete(code) : next.add(code);
      return next;
    });
  }

  function renderStep2() {
    return (
      <div className="card gap">
        <div className="ch">
          <div><div className="ch-title">🗂 SDTM Domain Selection</div><div className="ch-sub">AI-predicted domains pre-selected · Physicians can override</div></div>
          <div style={{ display:'flex', gap:'.35rem' }}>
            <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setSelDomains(new Set(CDISC_DOMAINS.map(d=>d.code)))}>All</button>
            <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setSelDomains(new Set())}>None</button>
          </div>
        </div>
        <div className="cb">
          <div className="ai-bub"><b>Cohere prediction:</b> Based on extracted EHR data, these domains are predicted: <b>DM</b> Demographics, <b>VS</b> Vital Signs, <b>LB</b> Labs, <b>CM</b> Medications, <b>MH</b> Medical History, <b>AE</b> Adverse Events. Toggle any domain to include or exclude.</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'.4rem', marginBottom:'.8rem' }}>
            {CDISC_DOMAINS.map(d => (
              <div key={d.code} className={`dom-card${selDomains.has(d.code)?' on':''}`} onClick={()=>toggleDomain(d.code)}>
                <div style={{ fontFamily:"'DM Mono',monospace", fontSize:'.73rem', fontWeight:600, color: selDomains.has(d.code)?'var(--lavender)':'var(--muted)' }}>{d.code}</div>
                <div style={{ fontSize:'.55rem', color: selDomains.has(d.code)?'var(--dim)':'var(--muted)', marginTop:'.09rem', lineHeight:1.35 }}>{d.name}</div>
              </div>
            ))}
          </div>
          <button className="btn btn-p" onClick={()=>{ if(!selDomains.size){toast('No domains','Select at least one','⚠️');return;} setStep(3); }}>Continue to Variable Mapping →</button>
        </div>
      </div>
    );
  }

  /* ── Step 3: Variable mapping ── */
  const domList = [...selDomains];
  const filteredVars = domFilter==='all' ? vars : vars.filter(v=>v.domain===domFilter);

  function updateVar(idx, field, val) {
    setVars(v => { const next=[...v]; next[idx]={...next[idx],[field]:val}; return next; });
  }
  function deleteVar(idx) { setVars(v=>v.filter((_,i)=>i!==idx)); }
  function addVar() {
    if (!newRow.variable || !newRow.value) { toast('Missing fields','Variable and Value required','⚠️'); return; }
    setVars(v=>[...v,{...newRow,label:newRow.label||newRow.variable,confidence:100,source:'Manual'}]);
    setNewRow({domain:domList[0]||'DM',variable:'',label:'',value:''});
    setShowAddRow(false);
    toast('Row added',`${newRow.domain}.${newRow.variable} = ${newRow.value}`,'✅');
  }

  function renderStep3() {
    return (
      <div className="card gap">
        <div className="ch">
          <div><div className="ch-title">📋 CDISC Variable Mapping</div><div className="ch-sub">Review, edit, add or remove variables</div></div>
          <div style={{ display:'flex', gap:'.35rem', alignItems:'center' }}>
            <select className="inp" value={domFilter} onChange={e=>setDomFilter(e.target.value)} style={{ width:130, fontSize:'.68rem' }}>
              <option value="all">All Domains</option>
              {domList.map(d=><option key={d} value={d}>{d}</option>)}
            </select>
            <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setShowAddRow(s=>!s)}>+ Add Row</button>
            <button className="btn btn-p" style={{ fontSize:'.68rem' }} onClick={()=>setStep(4)}>Generate CSV →</button>
          </div>
        </div>
        <div style={{ overflow:'auto', maxHeight:360 }}>
          <table className="var-tbl">
            <thead><tr><th>Domain</th><th>Variable</th><th>Label</th><th>Value</th><th>Conf.</th><th>Source</th><th/></tr></thead>
            <tbody>
              {filteredVars.map((v,i) => {
                const realIdx = vars.indexOf(v);
                const col = v.confidence>=85?'var(--green)':v.confidence>=70?'var(--yellow)':'var(--red)';
                return (
                  <tr key={i}>
                    <td><span className="chip chip-v">{v.domain}</span></td>
                    <td><input className="var-inp" value={v.variable} onChange={e=>updateVar(realIdx,'variable',e.target.value)}/></td>
                    <td><input className="var-inp" value={v.label}    onChange={e=>updateVar(realIdx,'label',e.target.value)}/></td>
                    <td><input className="var-inp" value={v.value}    onChange={e=>updateVar(realIdx,'value',e.target.value)}/></td>
                    <td><div style={{ display:'flex', alignItems:'center', gap:'.4rem' }}>
                      <div style={{ height:4, borderRadius:100, background:'rgba(255,255,255,.05)', overflow:'hidden', width:50 }}><div style={{ height:'100%', borderRadius:100, width:`${v.confidence}%`, background:col }}/></div>
                      <span style={{ fontSize:'.6rem', color:col }}>{v.confidence}%</span>
                    </div></td>
                    <td><span className={`chip chip-${v.source==='EHR'?'b':'v'}`}>{v.source}</span></td>
                    <td><button onClick={()=>deleteVar(realIdx)} style={{ padding:'.18rem .4rem', borderRadius:5, fontSize:'.6rem', background:'var(--rbg)', border:'1px solid rgba(239,68,68,.2)', color:'var(--red)', cursor:'pointer' }}>✕</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {showAddRow && (
          <div style={{ padding:'.8rem 1.1rem', borderTop:'1px solid var(--border)', display:'flex', gap:'.42rem', flexWrap:'wrap' }}>
            <select className="inp" value={newRow.domain} onChange={e=>setNewRow(r=>({...r,domain:e.target.value}))} style={{ width:90, fontSize:'.68rem' }}>
              {domList.map(d=><option key={d}>{d}</option>)}
            </select>
            {[['variable','Variable'],['label','Label'],['value','Value']].map(([f,p])=>(
              <input key={f} className="inp" placeholder={p} value={newRow[f]} onChange={e=>setNewRow(r=>({...r,[f]:e.target.value}))} style={{ flex:1 }}/>
            ))}
            <button className="btn btn-p" style={{ fontSize:'.68rem' }} onClick={addVar}>Add</button>
            <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>setShowAddRow(false)}>✕</button>
          </div>
        )}
      </div>
    );
  }

  /* ── Step 4: CSV export ── */
  async function loadReview() {
    if (review) return;
    setReviewLoading(true);
    let r = null;
    if (aiKeys.anthropic) {
      try {
        const res = await fetch('https://api.anthropic.com/v1/messages', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:300, messages:[{role:'user',content:`Briefly review this CDISC SDTM mapping for compliance in under 80 words. Note missing required variables if any.\n\n${vars.map(v=>`${v.domain}.${v.variable}="${v.value}"(${v.confidence}%)`).join(', ')}`}] }) });
        const d = await res.json(); r = d.content?.[0]?.text;
      } catch {}
    }
    setReview(r || `Mapping complete for ${[...new Set(vars.map(v=>v.domain))].join(', ')} domains. Required variables SUBJID, AGE, SEX present. Verify LBDTC and CMSTDTC for full SDTM 3.4 compliance.${aiKeys.anthropic?'':' (Add Anthropic key for live review.)'}`);
    setReviewLoading(false);
  }

  function downloadCSV() {
    const hdrs = ['STUDYID','DOMAIN','USUBJID','VARIABLE','LABEL','VALUE','CONFIDENCE','SOURCE','DATETIME'];
    const rows = vars.map(v=>['"CARE-2024-001"',`"${v.domain}"`,'"AN-2024-001"',`"${v.variable}"`,`"${v.label}"`,`"${v.value}"`,`"${v.confidence}%"`,`"${v.source}"`,`"${new Date().toISOString()}"`].join(','));
    const csv = [hdrs.join(','),...rows].join('\n');
    const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
    a.download=`SDTM_mapping_${new Date().toISOString().slice(0,10)}.csv`; a.click();
    toast('Downloaded',`${vars.length} rows · SDTM v3.4`,'⬇');
  }

  function renderStep4() {
    if (!review && !reviewLoading) loadReview();
    const doms = [...new Set(vars.map(v=>v.domain))];
    const score = Math.round(vars.reduce((a,v)=>a+v.confidence,0)/(vars.length||1));
    const scoreColor = score>=85?'var(--green)':score>=70?'var(--yellow)':'var(--red)';
    const hdrs = ['STUDYID','DOMAIN','USUBJID','VARIABLE','LABEL','VALUE','CONFIDENCE','SOURCE','DATETIME'];
    return (
      <div className="g32">
        <div className="card gap">
          <div className="ch">
            <div><div className="ch-title">📊 CSV Preview — SDTM v3.4</div><div className="ch-sub">{vars.length} rows · {doms.join(', ')}</div></div>
            <div style={{ display:'flex', gap:'.35rem' }}>
              <button className="btn btn-p" style={{ fontSize:'.68rem' }} onClick={downloadCSV}>⬇ Download CSV</button>
              <button className="btn btn-g" style={{ fontSize:'.68rem' }} onClick={()=>{navigator.clipboard.writeText(vars.map(v=>[v.domain,v.variable,v.label,v.value,v.confidence+'%',v.source].join('\t')).join('\n'));toast('Copied','','📋');}}>📋 Copy</button>
            </div>
          </div>
          <div style={{ overflow:'auto', maxHeight:380 }}>
            <table className="csv-tbl">
              <thead><tr>{hdrs.map(h=><th key={h}>{h}</th>)}</tr></thead>
              <tbody>
                {vars.map((v,i)=>(
                  <tr key={i}>
                    <td>CARE-2024-001</td><td>{v.domain}</td><td>AN-2024-001</td>
                    <td>{v.variable}</td><td>{v.label}</td><td>{v.value}</td>
                    <td>{v.confidence}%</td><td>{v.source}</td>
                    <td>{new Date().toISOString().slice(0,19)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="col">
          <div className="card">
            <div className="ch"><div className="ch-title">📈 Compliance Report</div></div>
            <div className="cb" style={{ display:'flex', flexDirection:'column', gap:'.6rem' }}>
              <div style={{ textAlign:'center' }}>
                <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'2rem', fontWeight:700, color:scoreColor }}>{score}%</div>
                <div style={{ fontSize:'.63rem', color:'var(--muted)' }}>CDISC Compliance Score</div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:'.38rem', fontSize:'.71rem' }}>
                {[['Variables',vars.length],['Domains',doms.join(', ')],['High confidence ≥85%', vars.filter(v=>v.confidence>=85).length]].map(([l,v])=>(
                  <div key={l} style={{ display:'flex', justifyContent:'space-between' }}><span style={{ color:'var(--muted)' }}>{l}</span><span style={{ color: l.includes('High')?'var(--green)':'inherit' }}>{v}</span></div>
                ))}
              </div>
              <div style={{ padding:'.6rem', borderRadius:8, background:'var(--gbg)', border:'1px solid rgba(16,185,129,.15)', fontSize:'.67rem', color:'var(--green)' }}>✓ Ready for regulatory review</div>
            </div>
          </div>
          <div className="card">
            <div className="ch"><div className="ch-title">⚖ Claude Clinical Review</div><span style={{ fontSize:'.63rem', color: aiKeys.anthropic?'var(--green)':'var(--yellow)' }}>{aiKeys.anthropic?'Live':'Demo'}</span></div>
            <div className="cb" style={{ fontSize:'.72rem', color:'var(--dim)', lineHeight:1.75, minHeight:60 }}>
              {reviewLoading ? <><span className="pipe-spin" style={{ display:'inline-block', verticalAlign:'middle', marginRight:'.5rem' }}/>Generating review…</> : review}
            </div>
          </div>
          <div style={{ display:'flex', gap:'.45rem' }}>
            <button className="btn btn-g" style={{ flex:1, justifyContent:'center', fontSize:'.7rem' }} onClick={()=>{ setStep(0); setEhrText(''); setXrayName(''); setVars([]); setReview(''); setSelDomains(new Set(AI_PRED_DOMAINS)); setStageStatus(PIPELINE_STAGES.map(()=>'idle')); }}>← Start Over</button>
            <button className="btn btn-p" style={{ flex:1, justifyContent:'center', fontSize:'.7rem' }} onClick={downloadCSV}>⬇ Export CSV</button>
          </div>
        </div>
      </div>
    );
  }

  /* ── Step progress bar ── */
  const STEP_LABELS = ['Input','AI Extract','Domains','Variables','Export'];

  return (
    <div className="content fade-up">
      {/* Progress bar */}
      <div style={{ display:'flex', background:'var(--card)', border:'1px solid var(--border)', borderRadius:12, overflow:'hidden', marginBottom:'1.2rem' }}>
        {STEP_LABELS.map((l,i)=>(
          <div key={i} onClick={()=>jumpStep(i)} style={{
            flex:1, padding:'.68rem .4rem', textAlign:'center', fontSize:'.65rem', fontWeight:500, cursor: i<=step?'pointer':'default',
            color: i===step?'var(--white)':i<step?'var(--green)':'var(--muted)',
            background: i===step?'rgba(109,40,217,.18)':'transparent',
            borderRight: i<4?'1px solid var(--border)':'none',
            position:'relative', transition:'all .2s',
          }}>
            {i<step && <span style={{ position:'absolute', top:4, right:5, fontSize:'.48rem', color:'var(--green)' }}>✓</span>}
            <span style={{ fontSize:'.48rem', display:'block', marginBottom:'.1rem', color: i===step?'var(--lavender)':i<step?'var(--green)':'var(--muted)' }}>Step {i+1}</span>
            {l}
          </div>
        ))}
      </div>

      {step===0 && renderStep0()}
      {step===1 && renderStep1()}
      {step===2 && renderStep2()}
      {step===3 && renderStep3()}
      {step===4 && renderStep4()}
    </div>
  );
}
