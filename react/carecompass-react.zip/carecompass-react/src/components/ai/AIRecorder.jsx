// src/components/ai/AIRecorder.jsx
import { useState, useRef, useEffect } from 'react';
import { useApp } from '../../hooks/useApp';

const DEMO = [[0,'Good morning Amara. How are you feeling today?'],[1,'Good morning Doctor. Chest pain and difficulty breathing for about three weeks.'],[0,'On a scale of one to ten, how severe is the chest pain?'],[1,'About six or seven. Worse when I exert myself.'],[0,'Any palpitations or dizziness?'],[1,'Yes, my heart feels like it is racing sometimes.'],[0,'You are on Lisinopril. Taking it regularly?'],[1,'Yes every morning. But my blood pressure is still high.'],[0,'We will order blood work and refer you to Mount Sinai cardiology.'],[1,'Thank you doctor. I have been very worried.'],[0,'Your CareCompass navigator will coordinate everything in Igbo.']];

function fmtTime(s) { return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'); }

export function AIRecorder() {
  const { aiKeys, toast } = useApp();
  const [lines, setLines]       = useState([]);
  const [running, setRunning]   = useState(false);
  const [paused, setPaused]     = useState(false);
  const [secs, setSecs]         = useState(0);
  const [wordCount, setWordCount] = useState(0);
  const [counts, setCounts]     = useState({dr:0,pt:0});
  const [waveH, setWaveH]       = useState(Array(24).fill(4));
  const [insights, setInsights] = useState([]);
  const [insLoading, setInsLoading] = useState(false);
  const [spk1, setSpk1] = useState('Doctor');
  const [spk2, setSpk2] = useState('Patient');
  const boxRef  = useRef(null);
  const timerRef = useRef(null);
  const waveRef  = useRef(null);
  const demoRef  = useRef(null);
  const recoRef  = useRef(null);
  const secsRef  = useRef(0);

  useEffect(() => { if (boxRef.current) boxRef.current.scrollTop = 99999; }, [lines]);

  function addLine(text, spk) {
    setLines(l => [...l, { text, spk, time:Date.now(), ts:new Date().toLocaleTimeString('en-CA',{hour:'2-digit',minute:'2-digit',second:'2-digit'}) }]);
    setWordCount(w => w + text.split(/\s+/).length);
    setCounts(c => spk===0 ? {...c,dr:c.dr+1} : {...c,pt:c.pt+1});
  }

  function startRec() {
    setRunning(true); setPaused(false); setLines([]); setWordCount(0); setCounts({dr:0,pt:0}); setSecs(0); secsRef.current=0;
    timerRef.current = setInterval(() => { secsRef.current++; setSecs(secsRef.current); }, 1000);
    waveRef.current  = setInterval(() => setWaveH(Array(24).fill(0).map(()=>4+Math.random()*30)), 80);

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { startDemo(); return; }
    const r = new SR(); r.continuous=true; r.interimResults=true; r.lang='en-CA';
    recoRef.current = r;
    let spk=0;
    r.onresult = e => {
      let ft=''; for (let i=e.resultIndex;i<e.results.length;i++) if (e.results[i].isFinal) ft+=e.results[i][0].transcript+' ';
      if (ft.trim()) { addLine(ft.trim(),spk); spk=1-spk; }
    };
    r.onend = () => { if (running && !paused) r.start(); };
    r.start();
  }

  function startDemo() {
    let i=0;
    demoRef.current = setInterval(() => {
      if (i>=DEMO.length) { clearInterval(demoRef.current); return; }
      addLine(DEMO[i][1], DEMO[i][0]); i++;
    }, 2200);
  }

  function stopRec() {
    setRunning(false);
    clearInterval(timerRef.current); clearInterval(waveRef.current); clearInterval(demoRef.current);
    if (recoRef.current) try { recoRef.current.stop(); } catch{}
    setWaveH(Array(24).fill(4));
    toast('Recording stopped', `${lines.length+1} utterances · ${fmtTime(secsRef.current)}`, '⏹');
  }

  function togglePause() {
    if (!paused) { clearInterval(waveRef.current); if(recoRef.current) try{recoRef.current.stop();}catch{} }
    else { waveRef.current=setInterval(()=>setWaveH(Array(24).fill(0).map(()=>4+Math.random()*30)),80); if(recoRef.current) try{recoRef.current.start();}catch{} }
    setPaused(p=>!p);
  }

  async function runInsights() {
    if (!lines.length) { toast('No transcript','Record first','⚠️'); return; }
    setInsLoading(true);
    const transcript = lines.map(l=>`[${l.spk===0?spk1:spk2}]: ${l.text}`).join('\n');
    let result = null;
    if (aiKeys.anthropic) {
      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:600, messages:[{role:'user',content:`Analyze this transcript. Return labeled sections: CHIEF COMPLAINT, SYMPTOMS, MEDICATIONS, ACTION ITEMS, RISK FLAGS.\n\n${transcript}`}] }) });
        const d = await r.json(); result = d.content?.[0]?.text;
      } catch{}
    }
    const DEMO_INS = [
      {tag:'CHIEF COMPLAINT',text:'Chest tightness and shortness of breath, 3-week duration, worsening with exertion.',color:'#14b8a6'},
      {tag:'SYMPTOMS',text:'Palpitations (racing heart), exertional dyspnea, severity 6-7/10.',color:'#8b5cf6'},
      {tag:'MEDICATIONS',text:'Lisinopril 10mg daily — patient reports adherence but BP remains elevated.',color:'#10b981'},
      {tag:'ACTION ITEMS',text:'Cardiology referral ordered, blood work requested, BP recheck in 2 weeks.',color:'#c4b5fd'},
      {tag:'RISK FLAG',text:'Uncontrolled hypertension — consider dose escalation per physician judgment.',color:'#ef4444'},
    ];
    if (result) {
      const colors={CHIEF:'#14b8a6',SYMPTOM:'#8b5cf6',MEDICATION:'#10b981',ACTION:'#c4b5fd',RISK:'#ef4444'};
      const parsed=[];
      result.split('\n').forEach(line=>{ const m=line.match(/^([A-Z][A-Z\s]+):/); if(m){ const key=Object.keys(colors).find(k=>m[1].includes(k))||'CHIEF'; parsed.push({tag:m[1].trim(),text:line.replace(m[0],'').trim(),color:colors[key]}); }});
      setInsights(parsed.length?parsed:DEMO_INS);
    } else {
      setInsights(DEMO_INS);
    }
    setInsLoading(false);
    toast('Insights generated','AI clinical analysis complete','🤖');
  }

  function exportTr() {
    if (!lines.length) { toast('No transcript','','⚠️'); return; }
    const text = lines.map(l=>`[${fmtTime(Math.floor((l.time-lines[0].time)/1000))}] [${l.spk===0?spk1:spk2}] ${l.text}`).join('\n');
    const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));
    a.download=`transcript_${new Date().toISOString().slice(0,10)}.txt`; a.click();
    toast('Exported','Saved as .txt','📄');
  }

  return (
    <div className="content fade-up">
      <div className="g23">
        <div className="col">
          <div className="card">
            <div className="ch"><div><div className="ch-title">🎙 Doctor–Patient Recorder</div><div className="ch-sub">Real-time transcription with speaker diarization</div></div></div>
            <div className="cb" style={{textAlign:'center'}}>
              <div style={{width:76,height:76,borderRadius:'50%',background:running?'linear-gradient(135deg,var(--red),#f87171)':'linear-gradient(135deg,var(--violet),var(--amethyst))',border:'none',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'1.7rem',margin:'0 auto .9rem',position:'relative',boxShadow:running?'0 4px 20px rgba(239,68,68,.5)':'0 4px 20px rgba(109,40,217,.4)',transition:'all .28s'}} onClick={()=>running?stopRec():startRec()}>
                {running?'⏹':'🎙'}
                {running&&<span style={{position:'absolute',inset:-8,borderRadius:'50%',border:'2px solid rgba(239,68,68,.35)',animation:'ripple 1.5s infinite'}}/>}
              </div>
              <div style={{fontSize:'.76rem',color:'var(--muted)',marginBottom:'.32rem'}}>{running?'Recording…':'Click to start recording'}</div>
              <div style={{fontFamily:"'DM Mono',monospace",fontSize:'1.35rem',fontWeight:500,marginBottom:'.55rem'}}>{fmtTime(secs)}</div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:'2.5px',height:38,marginBottom:'.55rem'}}>
                {waveH.map((h,i)=><div key={i} className="wbar" style={{height:h}}/>)}
              </div>
              <div style={{display:'flex',justifyContent:'center',gap:'.5rem'}}>
                {running&&<button className="btn btn-g" style={{fontSize:'.69rem'}} onClick={togglePause}>{paused?'▶ Resume':'⏸ Pause'}</button>}
                <button className="btn btn-teal" style={{fontSize:'.69rem'}} onClick={runInsights}>🤖 AI Insights</button>
                <button className="btn btn-g" style={{fontSize:'.69rem'}} onClick={exportTr}>📄 Export</button>
                <button className="btn btn-g" style={{fontSize:'.69rem'}} onClick={()=>{setLines([]);setWordCount(0);setCounts({dr:0,pt:0});}}>🗑 Clear</button>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="ch"><div className="ch-title">📝 Speaker Labels</div></div>
            <div className="cb" style={{display:'flex',gap:'.65rem'}}>
              <div className="mfield" style={{flex:1,margin:0}}><label className="mlbl">Speaker 1 (Doctor)</label><input className="inp" value={spk1} onChange={e=>setSpk1(e.target.value)}/></div>
              <div className="mfield" style={{flex:1,margin:0}}><label className="mlbl">Speaker 2 (Patient)</label><input className="inp" value={spk2} onChange={e=>setSpk2(e.target.value)}/></div>
            </div>
          </div>

          {/* Transcript box */}
          <div className="card" style={{flex:1}}>
            <div className="ch"><div className="ch-title">📄 Live Transcript</div><span style={{fontFamily:"'DM Mono',monospace",fontSize:'.68rem',color:'var(--green)'}}>{lines.length} utterances</span></div>
            <div ref={boxRef} className="cb" style={{maxHeight:300,overflowY:'auto',minHeight:80}}>
              {!lines.length ? <div style={{fontSize:'.68rem',color:'var(--muted)',textAlign:'center',padding:'.4rem'}}>Start recording to see transcript here…</div>
                : lines.map((l,i)=>(
                  <div key={i} style={{display:'flex',gap:'.7rem',padding:'.65rem 0',borderBottom:'1px solid rgba(255,255,255,.04)'}}>
                    <div style={{flexShrink:0,width:70,display:'flex',flexDirection:'column',alignItems:'flex-end',gap:'.18rem'}}>
                      <span className={`spk-badge ${l.spk===0?'spk-dr':'spk-pt'}`}>{l.spk===0?spk1:spk2}</span>
                    </div>
                    <div style={{flex:1,fontSize:'.75rem',lineHeight:1.65,color:'var(--dim)'}}>{l.text}</div>
                    <span style={{fontFamily:"'DM Mono',monospace",fontSize:'.57rem',color:'var(--muted)',flexShrink:0}}>{l.ts}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card">
            <div className="ch"><div className="ch-title">📊 Session Stats</div></div>
            <div className="cb" style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'.6rem'}}>
              {[['Duration',fmtTime(secs)],['Words',wordCount],[spk1+' turns',counts.dr],[spk2+' turns',counts.pt]].map(([l,v])=>(
                <div key={l} style={{padding:'.65rem',borderRadius:9,background:'rgba(255,255,255,.025)',border:'1px solid var(--border)',textAlign:'center'}}>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:'1.2rem',fontWeight:700}}>{v}</div>
                  <div style={{fontSize:'.62rem',color:'var(--muted)',marginTop:'.1rem'}}>{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <div className="ch"><div className="ch-title">🤖 AI Clinical Insights</div><span style={{fontSize:'.63rem',color: aiKeys.anthropic?'var(--green)':'var(--yellow)'}}>{aiKeys.anthropic?'Live':'Demo'}</span></div>
            <div className="cb" style={{minHeight:100}}>
              {insLoading ? <div style={{fontSize:'.73rem',color:'var(--muted)'}}>Analyzing conversation… <span className="pipe-spin" style={{display:'inline-block',verticalAlign:'middle',marginLeft:'.5rem'}}/></div>
                : !insights.length ? <div style={{fontSize:'.7rem',color:'var(--muted)'}}>Record a conversation then click 🤖 AI Insights above.</div>
                : insights.map((s,i)=>(
                  <div key={i} className="insight-item">
                    <div className="ins-tag" style={{color:s.color}}>{s.tag}</div>{s.text}
                  </div>
                ))}
            </div>
          </div>

          <div className="card">
            <div className="ch"><div className="ch-title">⚙️ Settings</div></div>
            <div className="cb" style={{display:'flex',flexDirection:'column',gap:'.45rem'}}>
              <div className="mfield" style={{margin:0}}><label className="mlbl">Recording language</label><select className="inp"><option>en-CA (English Canada)</option><option>fr-CA (French Canada)</option></select></div>
              <label style={{display:'flex',alignItems:'center',gap:'.5rem',fontSize:'.72rem',cursor:'pointer',color:'var(--dim)'}}><input type="checkbox" defaultChecked style={{accentColor:'var(--amethyst)'}}/>Auto-translate patient speech</label>
              <label style={{display:'flex',alignItems:'center',gap:'.5rem',fontSize:'.72rem',cursor:'pointer',color:'var(--dim)'}}><input type="checkbox" defaultChecked style={{accentColor:'var(--amethyst)'}}/>Speaker diarization</label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
