// src/components/ai/AITranslation.jsx
import { useState, useRef } from 'react';
import { useApp } from '../../hooks/useApp';
import { CLINICAL_PHRASES, DEMO_TRANSLATIONS } from '../../data';

const LANGS = ['English','French','Spanish','Portuguese','Mandarin','Cantonese','Arabic','Urdu','Hindi','Punjabi','Tamil','Tagalog','Igbo','Yoruba','Somali','Tigrinya','Ukrainian','Polish','Korean','Japanese','Farsi','Vietnamese','Bengali'];

async function doTranslate(text, src, tgt, cohereKey) {
  if (src===tgt) return text;
  if (cohereKey) {
    try {
      const r = await fetch('https://api.cohere.com/v2/chat', { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${cohereKey}`}, body:JSON.stringify({ model:'command-a-translate-08-2025', messages:[{role:'user',content:`Translate from ${src} to ${tgt}. Output ONLY the translation:\n\n${text}`}], max_tokens:1000 }) });
      const d = await r.json();
      return d.message?.content?.[0]?.text || null;
    } catch { return null; }
  }
  const d = DEMO_TRANSLATIONS[text];
  return (d && d[tgt]) ? d[tgt] : `[${tgt}: "${text.substring(0,50)}${text.length>50?'…':''}" — add Cohere key for live translation]`;
}

export function AITranslation() {
  const { aiKeys, toast } = useApp();
  const [srcLang, setSrcLang] = useState('English');
  const [tgtLang, setTgtLang] = useState('Igbo');
  const [srcText, setSrcText] = useState('');
  const [tgtText, setTgtText] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [phrases, setPhrases] = useState(CLINICAL_PHRASES.slice(0,9));
  const debounce = useRef(null);

  async function translate(text=srcText, s=srcLang, t=tgtLang) {
    if (!text.trim()) return;
    setLoading(true);
    const result = await doTranslate(text, s, t, aiKeys.cohere);
    setTgtText(result || '');
    setLoading(false);
    setHistory(h => [{src:text,tgt:result,sL:s,tL:t,ts:new Date().toLocaleTimeString('en-CA',{hour:'2-digit',minute:'2-digit'})},...h.slice(0,19)]);
  }

  function debouncedTranslate(text) {
    setSrcText(text);
    clearTimeout(debounce.current);
    debounce.current = setTimeout(()=>translate(text),900);
  }

  function swap() {
    const [ns,nt,nst,ntt] = [tgtLang,srcLang,tgtText,srcText];
    setSrcLang(ns); setTgtLang(nt); setSrcText(nst); setTgtText(ntt);
  }

  return (
    <div className="content fade-up">
      <div className="g32">
        <div className="col">
          <div className="card">
            <div className="ch">
              <div><div className="ch-title">🌐 Real-Time Translation</div><div className="ch-sub">23 languages · clinical grade</div></div>
              <div style={{display:'flex',gap:'.35rem'}}>
                {['Text','Voice','Live'].map(m=>(
                  <button key={m} onClick={()=>m==='Voice'&&toast('Voice mode','Use Chrome for microphone input','🎙')} style={{padding:'.3rem .7rem',borderRadius:6,border:'none',fontFamily:"'DM Sans',sans-serif",fontSize:'.67rem',fontWeight:500,cursor:'pointer',transition:'all .2s',background: m==='Text'?'var(--violet)':'rgba(255,255,255,.04)',color: m==='Text'?'var(--white)':'var(--muted)'}}>{m}</button>
                ))}
              </div>
            </div>
            <div className="cb">
              <div style={{display:'flex',alignItems:'center',gap:'.8rem',marginBottom:'.85rem'}}>
                <select className="lang-sel" value={srcLang} onChange={e=>{setSrcLang(e.target.value);translate(srcText,e.target.value,tgtLang);}}>
                  {LANGS.map(l=><option key={l}>{l}</option>)}
                </select>
                <div onClick={swap} style={{width:36,height:36,borderRadius:'50%',background:'rgba(109,40,217,.2)',border:'1px solid rgba(139,92,246,.25)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:'.95rem',color:'var(--lavender)',flexShrink:0,transition:'all .22s'}} onMouseEnter={e=>e.target.style.transform='rotate(180deg)'} onMouseLeave={e=>e.target.style.transform=''}>⇄</div>
                <select className="lang-sel" value={tgtLang} onChange={e=>{setTgtLang(e.target.value);translate(srcText,srcLang,e.target.value);}}>
                  {LANGS.map(l=><option key={l}>{l}</option>)}
                </select>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr auto 1fr',gap:'.7rem',alignItems:'start',marginBottom:'.85rem'}}>
                <div>
                  <div style={{fontSize:'.58rem',fontWeight:600,letterSpacing:'.1em',textTransform:'uppercase',color:'var(--muted)',marginBottom:'.35rem'}}>{srcLang}</div>
                  <textarea className="tr-area" value={srcText} onChange={e=>debouncedTranslate(e.target.value)} placeholder="Type or paste text to translate…"/>
                  <div style={{fontSize:'.61rem',color:'var(--muted)',marginTop:'.35rem'}}>{srcText.length} chars</div>
                </div>
                <div style={{display:'flex',alignItems:'center',justifyContent:'center',paddingTop:'2.8rem',fontSize:'1.1rem',color:loading?'var(--amethyst)':'var(--muted)'}}>{loading?<div className="pipe-spin"/>:'→'}</div>
                <div>
                  <div style={{fontSize:'.58rem',fontWeight:600,letterSpacing:'.1em',textTransform:'uppercase',color:'var(--muted)',marginBottom:'.35rem'}}>{tgtLang}</div>
                  <textarea className="tr-area out" value={tgtText} readOnly placeholder="Translation will appear here…"/>
                  <div style={{display:'flex',gap:'.38rem',marginTop:'.35rem'}}>
                    <button className="btn btn-g" style={{fontSize:'.66rem',padding:'.3rem .6rem'}} onClick={()=>{navigator.clipboard.writeText(tgtText);toast('Copied','','📋');}}>📋</button>
                    <button className="btn btn-g" style={{fontSize:'.66rem',padding:'.3rem .6rem'}} onClick={()=>{if(window.speechSynthesis)window.speechSynthesis.speak(new SpeechSynthesisUtterance(tgtText));toast('Speaking…','','🔊');}}>🔊</button>
                  </div>
                </div>
              </div>
              <button className="btn btn-p" style={{width:'100%',justifyContent:'center'}} onClick={()=>translate()}>Translate →</button>
            </div>
          </div>

          <div className="card">
            <div className="ch"><div className="ch-title">📋 Translation History</div><button className="cl" onClick={()=>setHistory([])}>Clear</button></div>
            <div className="cb" style={{maxHeight:200,overflowY:'auto'}}>
              {!history.length ? <div style={{fontSize:'.68rem',color:'var(--muted)',textAlign:'center',padding:'.8rem'}}>No translations yet</div>
                : history.slice(0,8).map((h,i)=>(
                  <div key={i} style={{display:'flex',gap:'.65rem',padding:'.65rem 0',borderBottom:'1px solid rgba(255,255,255,.04)',fontSize:'.7rem'}}>
                    <span style={{fontSize:'.58rem',color:'var(--amethyst)',flexShrink:0,width:62}}>{h.sL.slice(0,4)}→{h.tL.slice(0,4)}</span>
                    <span style={{flex:1,color:'var(--dim)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{h.src.slice(0,42)}</span>
                    <span style={{flex:1,color:'var(--lavender)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{h.tgt?.slice(0,42)}</span>
                    <span style={{fontSize:'.56rem',color:'var(--muted)',flexShrink:0}}>{h.ts}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>

        <div className="col">
          <div className="card">
            <div className="ch"><div className="ch-title">⚡ Clinical Quick Phrases</div><button className="cl" onClick={()=>setPhrases(CLINICAL_PHRASES)}>Load more +</button></div>
            <div className="cb" style={{display:'grid',gridTemplateColumns:'repeat(1,1fr)',gap:'.35rem'}}>
              {phrases.map((p,i)=>(
                <button key={i} className="qph" onClick={()=>{setSrcText(p);translate(p);}}>{p}</button>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="ch"><div className="ch-title">📊 Session Stats</div></div>
            <div className="cb" style={{display:'flex',flexDirection:'column',gap:'.45rem',fontSize:'.73rem'}}>
              <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--muted)'}}>Translations</span><span style={{fontFamily:"'DM Mono',monospace"}}>{history.length}</span></div>
              <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--muted)'}}>Source language</span><span>{srcLang}</span></div>
              <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--muted)'}}>Target language</span><span>{tgtLang}</span></div>
              <div style={{display:'flex',justifyContent:'space-between'}}><span style={{color:'var(--muted)'}}>API key</span><span style={{color:aiKeys.cohere?'var(--green)':'var(--yellow)'}}>{aiKeys.cohere?'✓ Connected':'Demo mode'}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
