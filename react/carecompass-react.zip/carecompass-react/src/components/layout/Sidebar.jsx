// src/components/layout/Sidebar.jsx
import { useApp } from '../../hooks/useApp';
import { NAV_PAT, NAV_PROV } from '../../data';

export default function Sidebar() {
  const { role, setRole, view, go } = useApp();

  const ROLES = {
    patient:  { av:'AN', cls:'pat', name:'Amara Nwosu',  sub:'Patient · Igbo',         lang:'🌐 Igbo · English',    grad:'linear-gradient(135deg,#3b0764,#6d28d9)' },
    provider: { av:'AD', cls:'prov',name:'Dr. Adeyemi',  sub:'Provider · Scarborough', lang:'🏥 Scarborough Health', grad:'linear-gradient(135deg,#1e3a5f,#4f46e5)' },
  };
  const R   = ROLES[role];
  const nav = role === 'patient' ? NAV_PAT : NAV_PROV;

  return (
    <aside style={{ width:'var(--sidebar-w)', flexShrink:0, background:'var(--surface)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      {/* Logo */}
      <div style={{ padding:'1.05rem 1.15rem .85rem', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'.58rem', flexShrink:0 }}>
        <div style={{ width:29, height:29, borderRadius:8, background:'linear-gradient(135deg,#6d28d9,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'.82rem', boxShadow:'0 2px 10px rgba(109,40,217,.45)' }}>✛</div>
        <div>
          <div style={{ fontFamily:"'Playfair Display',serif", fontSize:'.92rem', fontWeight:700 }}>CareCompass</div>
          <div style={{ fontSize:'.52rem', color:'var(--muted)', letterSpacing:'.05em', textTransform:'uppercase' }}>GTA Navigator</div>
        </div>
      </div>

      {/* Role toggle */}
      <div style={{ margin:'.55rem .95rem', display:'flex', background:'rgba(255,255,255,.04)', border:'1px solid var(--border)', borderRadius:8, padding:2, flexShrink:0, gap:2 }}>
        {['patient','provider'].map(r => (
          <button key={r} onClick={() => setRole(r)} style={{
            flex:1, padding:'.34rem', borderRadius:6, border:'none',
            background: role===r ? 'var(--violet)' : 'transparent',
            color: role===r ? 'var(--white)' : 'var(--muted)',
            fontFamily:"'DM Sans',sans-serif", fontSize:'.67rem', fontWeight:500, cursor:'pointer',
            boxShadow: role===r ? '0 1px 6px rgba(109,40,217,.4)' : 'none',
            transition:'all .22s',
          }}>{r.charAt(0).toUpperCase()+r.slice(1)}</button>
        ))}
      </div>

      {/* User */}
      <div style={{ padding:'.7rem 1.05rem', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:'.58rem', flexShrink:0 }}>
        <div style={{ width:32, height:32, borderRadius:'50%', background:R.grad, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:"'Playfair Display',serif", fontSize:'.75rem', fontWeight:700, border:'1.5px solid rgba(139,92,246,.28)', flexShrink:0 }}>{R.av}</div>
        <div>
          <div style={{ fontSize:'.78rem', fontWeight:600, lineHeight:1.3 }}>{R.name}</div>
          <div style={{ fontSize:'.57rem', color:'var(--amethyst)', marginTop:'.06rem' }}>{R.sub}</div>
          <div style={{ fontSize:'.56rem', color:'var(--muted)', marginTop:'.04rem' }}>{R.lang}</div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding:'.5rem', flex:1, overflowY:'auto' }}>
        {nav.map(section => (
          <div key={section.section}>
            <div style={{ fontSize:'.52rem', fontWeight:600, letterSpacing:'.13em', textTransform:'uppercase', color:'var(--muted)', padding:'0 .58rem', margin:'.5rem 0 .22rem' }}>{section.section}</div>
            {section.items.map(item => {
              const active = view === item.id;
              return (
                <div key={item.id} onClick={() => go(item.id)} data-id={item.id} style={{
                  display:'flex', alignItems:'center', gap:'.55rem',
                  padding:'.52rem .6rem', borderRadius:8, fontSize:'.76rem',
                  color: active ? 'var(--white)' : 'var(--dim)',
                  background: active ? 'rgba(109,40,217,.18)' : 'transparent',
                  border: `1px solid ${active ? 'rgba(139,92,246,.18)' : 'transparent'}`,
                  cursor:'pointer', marginBottom:'.06rem', transition:'all .18s', userSelect:'none',
                }}
                onMouseEnter={e => { if (!active) { e.currentTarget.style.background='rgba(139,92,246,.07)'; e.currentTarget.style.color='var(--white)'; }}}
                onMouseLeave={e => { if (!active) { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--dim)'; }}}
                >
                  <span style={{ fontSize:'.82rem', width:17, textAlign:'center', flexShrink:0 }}>{item.icon}</span>
                  {item.label}
                  {item.badge && (
                    <span style={{ marginLeft:'auto', padding:'.04rem .35rem', borderRadius:100, fontSize:'.54rem', fontWeight:700, background: item.bc==='g'?'var(--green)':item.bc==='r'?'var(--red)':item.bc==='y'?'var(--yellow)':'var(--violet)', color: item.bc==='y'?'#000':'var(--white)' }}>{item.badge}</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div style={{ padding:'.7rem 1.05rem', borderTop:'1px solid var(--border)', fontSize:'.58rem', color:'var(--muted)', flexShrink:0, lineHeight:1.65 }}>
        PHIPA · PIPEDA Compliant<br/>Secure · End-to-end Encrypted
      </div>
    </aside>
  );
}
